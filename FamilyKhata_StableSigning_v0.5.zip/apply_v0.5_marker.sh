#!/usr/bin/env bash
set -euo pipefail
FILE="app/src/main/java/com/familykhata/app/ui/FamilyKhataApp.kt"
OLD='v0.4 • Baki History'
NEW='v0.5 • Stable Update'

grep -Fq "$OLD" "$FILE" || {
  echo "Expected v0.4 marker not found; stopping without modifying UI."
  exit 1
}
sed -i "s/$OLD/$NEW/" "$FILE"
rm -- "$0"
