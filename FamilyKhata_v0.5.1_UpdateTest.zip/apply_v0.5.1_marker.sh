#!/usr/bin/env bash
set -euo pipefail

FILE="app/src/main/java/com/familykhata/app/ui/FamilyKhataApp.kt"
OLD='Text("v0.5 • Stable Update", style = MaterialTheme.typography.labelSmall)'
NEW='Text("v0.5.1 • Update Test", style = MaterialTheme.typography.labelSmall)'

test -f "$FILE"
grep -Fq "$OLD" "$FILE"

python3 - "$FILE" "$OLD" "$NEW" <<'PY'
from pathlib import Path
import sys
path = Path(sys.argv[1])
old = sys.argv[2]
new = sys.argv[3]
text = path.read_text(encoding="utf-8")
count = text.count(old)
if count != 1:
    raise SystemExit(f"Expected marker exactly once, found {count}")
path.write_text(text.replace(old, new, 1), encoding="utf-8")
PY

grep -Fq "$NEW" "$FILE"
! grep -Fq "$OLD" "$FILE"
echo "v0.5.1 marker updated"
