#!/usr/bin/env bash
set -euo pipefail

FILE="app/src/main/java/com/familykhata/app/ui/FamilyKhataApp.kt"
test -f "$FILE"

python3 - "$FILE" <<'PY'
from pathlib import Path
import sys

path = Path(sys.argv[1])
text = path.read_text(encoding="utf-8")

def replace_once(old, new, label):
    global text
    count = text.count(old)
    if count != 1:
        raise SystemExit(f"{label}: expected exactly 1 match, found {count}")
    text = text.replace(old, new, 1)

replace_once(
    "import androidx.compose.foundation.layout.padding\n",
    "import androidx.compose.foundation.layout.padding\n"
    "import androidx.compose.foundation.shape.RoundedCornerShape\n",
    "RoundedCornerShape import"
)
replace_once(
    "import androidx.compose.material3.Scaffold\n",
    "import androidx.compose.material3.Scaffold\n"
    "import androidx.compose.material3.Surface\n",
    "Surface import"
)
replace_once(
    "import androidx.compose.ui.Modifier\n",
    "import androidx.compose.ui.Modifier\n"
    "import androidx.compose.ui.graphics.Color\n",
    "Color import"
)

replace_once("    MaterialTheme {\n", "    HisabiKhataTheme {\n", "theme")

replace_once(
    "                NavigationBar {\n",
    "                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {\n",
    "navigation bar"
)

replace_once(
    '''                Text("Family Khata", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("v0.6 • Play Ready Build", style = MaterialTheme.typography.labelSmall)
                Spacer(Modifier.height(10.dp))
''',
    '''                BrandHeader()
                Spacer(Modifier.height(14.dp))
''',
    "brand header call"
)

old_dashboard = '''@Composable
private fun DashboardScreen(viewModel: FamilyKhataViewModel) {
    val totals by viewModel.totals.collectAsState()
    val bakiPeople by viewModel.bakiPeople.collectAsState()
    val receivable = bakiPeople.filter { it.balance > 0 }.sumOf { it.balance }
    val payable = -bakiPeople.filter { it.balance < 0 }.sumOf { it.balance }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SummaryCard("মোট আয়", totals.income)
        SummaryCard("মোট খরচ", totals.expense)
        SummaryCard("বর্তমান ব্যালেন্স", totals.income - totals.expense)
        SummaryCard("পাবো", receivable)
        SummaryCard("দেবো", payable)
    }
}

@Composable
private fun SummaryCard(title: String, amount: Double) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge)
            Text("৳ ${money(amount)}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
    }
}
'''

new_dashboard = '''@Composable
private fun BrandHeader() {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.primaryContainer
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 15.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        "হিসাবী খাতা",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        "আপনার টাকা-পয়সার সহজ হিসাব",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
                Surface(
                    shape = RoundedCornerShape(50),
                    color = MaterialTheme.colorScheme.primary
                ) {
                    Text(
                        "পরিবার",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                }
            }
            Text(
                "v0.7 • Brand UI",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
    }
}

@Composable
private fun DashboardScreen(viewModel: FamilyKhataViewModel) {
    val totals by viewModel.totals.collectAsState()
    val bakiPeople by viewModel.bakiPeople.collectAsState()
    val receivable = bakiPeople.filter { it.balance > 0 }.sumOf { it.balance }
    val payable = -bakiPeople.filter { it.balance < 0 }.sumOf { it.balance }
    val balance = totals.income - totals.expense

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.primary
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    "বর্তমান ব্যালেন্স",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onPrimary
                )
                Text(
                    "৳ ${money(balance)}",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimary
                )
                Text(
                    "পরিবারের সার্বিক হিসাব",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimary
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricCard(
                title = "মোট আয়",
                amount = totals.income,
                modifier = Modifier.weight(1f),
                containerColor = MaterialTheme.colorScheme.primaryContainer
            )
            MetricCard(
                title = "মোট খরচ",
                amount = totals.expense,
                modifier = Modifier.weight(1f),
                containerColor = MaterialTheme.colorScheme.secondaryContainer
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricCard(
                title = "পাবো",
                amount = receivable,
                modifier = Modifier.weight(1f),
                containerColor = MaterialTheme.colorScheme.tertiaryContainer
            )
            MetricCard(
                title = "দেবো",
                amount = payable,
                modifier = Modifier.weight(1f),
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surfaceVariant
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Text("হিসাব গুছিয়ে রাখুন", fontWeight = FontWeight.Bold)
                Text(
                    "নিচের “নতুন” থেকে আয়-খরচ এবং “বাকি” থেকে দেনা-পাওনা যোগ করুন।",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
private fun MetricCard(
    title: String,
    amount: Double,
    modifier: Modifier = Modifier,
    containerColor: Color = MaterialTheme.colorScheme.surfaceVariant
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = containerColor
    ) {
        Column(
            modifier = Modifier.padding(15.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Text(title, style = MaterialTheme.typography.labelLarge)
            Text(
                "৳ ${money(amount)}",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
'''

replace_once(old_dashboard, new_dashboard, "dashboard")

path.write_text(text, encoding="utf-8")
PY

grep -Fq 'HisabiKhataTheme {' "$FILE"
grep -Fq '"হিসাবী খাতা"' "$FILE"
grep -Fq '"v0.7 • Brand UI"' "$FILE"
grep -Fq 'private fun MetricCard' "$FILE"
! grep -Fq 'Text("Family Khata"' "$FILE"

echo "v0.7 branding UI applied"
