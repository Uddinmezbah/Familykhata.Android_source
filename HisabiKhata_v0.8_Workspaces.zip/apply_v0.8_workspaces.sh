#!/usr/bin/env bash
set -euo pipefail

FILE="app/src/main/java/com/familykhata/app/ui/FamilyKhataApp.kt"
test -f "$FILE"

python3 - "$FILE" <<'PY'
from pathlib import Path
import sys

path = Path(sys.argv[1])
text = path.read_text(encoding="utf-8")

def replace_once(old, new, label):
    global text
    count = text.count(old)
    if count != 1:
        raise SystemExit(f"{label}: expected exactly 1 match, found {count}")
    text = text.replace(old, new, 1)

replace_once(
'''fun FamilyKhataApp(viewModel: FamilyKhataViewModel) {
    var tab by remember { mutableStateOf(Tab.DASHBOARD) }

    HisabiKhataTheme {
''',
'''fun FamilyKhataApp(viewModel: FamilyKhataViewModel) {
    var tab by remember { mutableStateOf(Tab.DASHBOARD) }
    val workspace by viewModel.selectedWorkspace.collectAsState()

    HisabiKhataTheme {
''',
"workspace state"
)

replace_once(
'''                BrandHeader()
                Spacer(Modifier.height(14.dp))
''',
'''                BrandHeader(workspace)
                Spacer(Modifier.height(10.dp))
                WorkspaceSwitcher(
                    selected = workspace,
                    onSelect = {
                        viewModel.selectWorkspace(it)
                        tab = Tab.DASHBOARD
                    }
                )
                Spacer(Modifier.height(12.dp))
''',
"header + switcher"
)

replace_once(
'''                        Tab.DASHBOARD -> DashboardScreen(viewModel)
                        Tab.ADD -> AddTransactionScreen(viewModel)
                        Tab.BAKI -> BakiScreen(viewModel)
                        Tab.HISTORY -> HistoryScreen(viewModel)
''',
'''                        Tab.DASHBOARD -> DashboardScreen(viewModel, workspace)
                        Tab.ADD -> AddTransactionScreen(viewModel)
                        Tab.BAKI -> BakiScreen(viewModel, workspace)
                        Tab.HISTORY -> HistoryScreen(viewModel)
''',
"screen routing"
)

replace_once(
'''private fun BrandHeader() {
''',
'''private fun BrandHeader(workspace: String) {
''',
"brand header signature"
)

replace_once(
'''                        "আপনার টাকা-পয়সার সহজ হিসাব",
''',
'''                        "নিজের, পরিবারের ও দোকানের হিসাব এক জায়গায়",
''',
"brand subtitle"
)

replace_once(
'''                        "পরিবার",
''',
'''                        workspaceLabel(workspace),
''',
"workspace badge"
)

replace_once(
'''                "v0.7 • Brand UI",
''',
'''                "v0.8 • Smart Workspaces",
''',
"version marker"
)

marker = '''@Composable
private fun DashboardScreen(viewModel: FamilyKhataViewModel) {
'''
if text.count(marker) != 1:
    raise SystemExit(f"dashboard marker: expected 1 match, found {text.count(marker)}")

switcher = '''@Composable
private fun WorkspaceSwitcher(
    selected: String,
    onSelect: (String) -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                "কোন হিসাব দেখবেন?",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                WorkspaceButton(
                    label = "নিজের",
                    value = "PERSONAL",
                    selected = selected,
                    modifier = Modifier.weight(1f),
                    onSelect = onSelect
                )
                WorkspaceButton(
                    label = "পরিবার",
                    value = "FAMILY",
                    selected = selected,
                    modifier = Modifier.weight(1f),
                    onSelect = onSelect
                )
                WorkspaceButton(
                    label = "দোকান",
                    value = "SHOP",
                    selected = selected,
                    modifier = Modifier.weight(1f),
                    onSelect = onSelect
                )
            }
        }
    }
}

@Composable
private fun WorkspaceButton(
    label: String,
    value: String,
    selected: String,
    modifier: Modifier,
    onSelect: (String) -> Unit
) {
    if (selected == value) {
        Button(
            onClick = { onSelect(value) },
            modifier = modifier
        ) { Text(label) }
    } else {
        OutlinedButton(
            onClick = { onSelect(value) },
            modifier = modifier
        ) { Text(label) }
    }
}

@Composable
private fun DashboardScreen(viewModel: FamilyKhataViewModel, workspace: String) {
'''
text = text.replace(marker, switcher, 1)

replace_once(
'''                    "পরিবারের সার্বিক হিসাব",
''',
'''                    workspaceSummary(workspace),
''',
"dashboard workspace summary"
)

replace_once(
'''private fun BakiScreen(viewModel: FamilyKhataViewModel) {
''',
'''private fun BakiScreen(viewModel: FamilyKhataViewModel, workspace: String) {
''',
"baki screen signature"
)

replace_once(
'''            people = people,
            viewModel = viewModel,
            onSelect = { selectedId = it.id }
''',
'''            people = people,
            viewModel = viewModel,
            workspace = workspace,
            onSelect = { selectedId = it.id }
''',
"baki people call"
)

replace_once(
'''private fun BakiPeopleScreen(
    people: List<BakiPersonSummary>,
    viewModel: FamilyKhataViewModel,
    onSelect: (BakiPersonSummary) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
''',
'''private fun BakiPeopleScreen(
    people: List<BakiPersonSummary>,
    viewModel: FamilyKhataViewModel,
    workspace: String,
    onSelect: (BakiPersonSummary) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    val personLabel = if (workspace == "SHOP") "কাস্টমার/সাপ্লায়ার" else "ব্যক্তি"
''',
"baki people signature"
)

replace_once(
'''        Text("নতুন ব্যক্তি", fontWeight = FontWeight.Bold)
''',
'''        Text("নতুন $personLabel", fontWeight = FontWeight.Bold)
''',
"new person label"
)

replace_once(
''') { Text("ব্যক্তি যোগ করুন") }
''',
''') { Text("$personLabel যোগ করুন") }
''',
"add person button"
)

replace_once(
'''            Text("প্রথমে একজন ব্যক্তি যোগ করুন।")
''',
'''            Text("প্রথমে একজন $personLabel যোগ করুন।")
''',
"empty person message"
)

helper_marker = '''private fun actionLabel(action: String): String = when (action) {
'''
if text.count(helper_marker) != 1:
    raise SystemExit(f"helper marker: expected 1 match, found {text.count(helper_marker)}")

helpers = '''private fun workspaceLabel(workspace: String): String = when (workspace) {
    "PERSONAL" -> "নিজের"
    "SHOP" -> "দোকান"
    else -> "পরিবার"
}

private fun workspaceSummary(workspace: String): String = when (workspace) {
    "PERSONAL" -> "আপনার ব্যক্তিগত আয়-খরচ ও দেনা-পাওনা"
    "SHOP" -> "দোকানের আয়-খরচ ও দেনা-পাওনার হিসাব"
    else -> "পরিবারের সার্বিক আয়-খরচ ও দেনা-পাওনা"
}

private fun actionLabel(action: String): String = when (action) {
'''
text = text.replace(helper_marker, helpers, 1)

path.write_text(text, encoding="utf-8")
PY

grep -Fq 'val workspace by viewModel.selectedWorkspace.collectAsState()' "$FILE"
grep -Fq 'WorkspaceSwitcher(' "$FILE"
grep -Fq '"v0.8 • Smart Workspaces"' "$FILE"
grep -Fq '"PERSONAL"' "$FILE"
grep -Fq '"SHOP"' "$FILE"
grep -Fq 'private fun BakiScreen(viewModel: FamilyKhataViewModel, workspace: String)' "$FILE"
! grep -Fq '"v0.7 • Brand UI"' "$FILE"

echo "v0.8 workspace UI applied"
