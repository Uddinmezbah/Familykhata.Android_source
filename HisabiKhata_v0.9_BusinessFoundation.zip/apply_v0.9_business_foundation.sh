#!/usr/bin/env bash
set -euo pipefail

UI="app/src/main/java/com/familykhata/app/ui/FamilyKhataApp.kt"
GRADLE="app/build.gradle.kts"
WORKFLOW=".github/workflows/android-build.yml"
PAYLOAD="v0.9_payload"

EXPECTED_UI="a0758616cff519a54e4bddf6a6fc978578651e7f"
EXPECTED_GRADLE="8aaf5347ce27db7e91b426ed7737d7378d032904"
EXPECTED_WORKFLOW="ada282cf20e73f6b13a291b0baecb17d63dc1b30"

for path in "$UI" "$GRADLE" "$WORKFLOW"; do
  test -f "$path" || { echo "STOP: missing $path"; exit 1; }
done

test "$(git hash-object "$UI")" = "$EXPECTED_UI" || {
  echo "STOP: FamilyKhataApp.kt is not the verified v0.8 baseline"
  exit 1
}
test "$(git hash-object "$GRADLE")" = "$EXPECTED_GRADLE" || {
  echo "STOP: app/build.gradle.kts is not the verified v0.8 baseline"
  exit 1
}
test "$(git hash-object "$WORKFLOW")" = "$EXPECTED_WORKFLOW" || {
  echo "STOP: workflow is not the verified v0.8 baseline"
  exit 1
}

test -f "$PAYLOAD/$UI"
test -f "$PAYLOAD/$GRADLE"
test -f "$PAYLOAD/$WORKFLOW"

cp "$PAYLOAD/$UI" "$UI"
cp "$PAYLOAD/$GRADLE" "$GRADLE"
cp "$PAYLOAD/$WORKFLOW" "$WORKFLOW"

grep -Fq 'versionCode = 10' "$GRADLE"
grep -Fq 'versionName = "0.9.0"' "$GRADLE"
grep -Fq 'applicationId = "com.familykhata.app"' "$GRADLE"
grep -Fq 'keyAlias = "familykhata"' "$GRADLE"
grep -Fq 'v0.9 • Business Foundation' "$UI"
grep -Fq 'দোকান/প্রতিষ্ঠান' "$UI"
grep -Fq 'BusinessDashboard(' "$UI"
grep -Fq 'BusinessActionCard(' "$UI"
grep -Fq 'HisabiKhata-v0.9-play-aab' "$WORKFLOW"
grep -Fq 'HisabiKhata-v0.9-direct-apk' "$WORKFLOW"
! grep -Fq 'import androidx.compose.foundation.layout.weight' "$UI"

rm -rf "$PAYLOAD"
echo "v0.9 business foundation applied"
