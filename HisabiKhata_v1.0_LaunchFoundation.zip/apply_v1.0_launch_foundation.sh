#!/usr/bin/env bash
set -euo pipefail

ROOT="$(pwd)"
PAYLOAD="$ROOT/v1.0_payload"

fail() {
  echo "ERROR: $*" >&2
  exit 1
}

test -d "$PAYLOAD" || fail "v1.0_payload folder not found. Run this script from the repository root after unzipping."

grep -Fq 'versionCode = 10' app/build.gradle.kts || fail "Expected v0.9 versionCode 10 before applying v1.0."
grep -Fq 'versionName = "0.9.0"' app/build.gradle.kts || fail "Expected v0.9 versionName before applying v1.0."
grep -Fq 'v0.9 • Business Foundation' app/src/main/java/com/familykhata/app/ui/FamilyKhataApp.kt || fail "Expected v0.9 UI marker before applying v1.0."
grep -Fq 'version = 2' app/src/main/java/com/familykhata/app/data/AppDatabase.kt || fail "Unexpected Room database version."
grep -Fq 'Migration(1, 2)' app/src/main/java/com/familykhata/app/data/AppDatabase.kt || fail "Existing Room migration missing."
! grep -Fq 'fallbackToDestructiveMigration' app/src/main/java/com/familykhata/app/data/AppDatabase.kt || fail "Destructive migration must not be enabled."
! grep -Fq 'import androidx.compose.foundation.layout.weight' app/src/main/java/com/familykhata/app/ui/FamilyKhataApp.kt || fail "Invalid layout.weight import found before patch."

cp -R "$PAYLOAD"/. "$ROOT"/
rm -rf "$PAYLOAD"

grep -Fq 'versionCode = 11' app/build.gradle.kts || fail "v1.0 versionCode missing."
grep -Fq 'versionName = "1.0.0"' app/build.gradle.kts || fail "v1.0 versionName missing."
grep -Fq 'applicationId = "com.familykhata.app"' app/build.gradle.kts || fail "Application ID changed unexpectedly."
grep -Fq 'keyAlias = "familykhata"' app/build.gradle.kts || fail "Stable signing alias changed unexpectedly."
grep -Fq 'v1.0 • Launch Foundation' app/src/main/java/com/familykhata/app/ui/FamilyKhataApp.kt || fail "v1.0 UI marker missing."
grep -Fq 'MORE("আরও")' app/src/main/java/com/familykhata/app/ui/FamilyKhataApp.kt || fail "More tab missing."
grep -Fq 'SMS-এ হিসাব পাঠান' app/src/main/java/com/familykhata/app/ui/FamilyKhataApp.kt || fail "SMS feature missing."
grep -Fq 'ব্যাকআপ তৈরি করুন' app/src/main/java/com/familykhata/app/ui/FamilyKhataApp.kt || fail "Backup UI missing."
grep -Fq 'ব্যাকআপ রিস্টোর করুন' app/src/main/java/com/familykhata/app/ui/FamilyKhataApp.kt || fail "Restore UI missing."
grep -Fq 'APP_PACKAGE = "com.familykhata.app"' app/src/main/java/com/familykhata/app/ui/FamilyKhataApp.kt || fail "Play Store package link missing."
grep -Fq 'hisabi-khata-backup' app/src/main/java/com/familykhata/app/FamilyKhataViewModel.kt || fail "Backup format missing."
grep -Fq 'database.withTransaction' app/src/main/java/com/familykhata/app/FamilyKhataViewModel.kt || fail "Transactional restore missing."
grep -Fq 'suspend fun getAllTransactions' app/src/main/java/com/familykhata/app/data/FamilyKhataDao.kt || fail "Backup DAO query missing."
grep -Fq 'suspend fun clearBakiEntries' app/src/main/java/com/familykhata/app/data/FamilyKhataDao.kt || fail "Restore DAO clear missing."
grep -Fq 'HisabiKhata-v1.0-play-aab' .github/workflows/android-build.yml || fail "v1.0 AAB artifact name missing."
grep -Fq 'HisabiKhata-v1.0-direct-apk' .github/workflows/android-build.yml || fail "v1.0 APK artifact name missing."
test -s app/src/main/res/drawable/ic_launcher_foreground.xml || fail "New launcher logo foreground missing."
grep -Fq '#F4B942' app/src/main/res/drawable/ic_launcher_foreground.xml || fail "New brand gold accent missing."
test -s docs/index.html || fail "Website home missing."
test -s docs/privacy.html || fail "Privacy page missing."
test -s docs/support.html || fail "Support page missing."
! grep -Fq 'android.permission.SEND_SMS' app/src/main/AndroidManifest.xml || fail "SEND_SMS permission must not be requested."
! grep -Fq 'import androidx.compose.foundation.layout.weight' app/src/main/java/com/familykhata/app/ui/FamilyKhataApp.kt || fail "Invalid layout.weight import introduced."

echo "v1.0 launch foundation applied"
