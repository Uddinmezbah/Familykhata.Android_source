#!/usr/bin/env bash
set -euo pipefail

ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
cd "$ROOT"

UI="app/src/main/java/com/familykhata/app/ui/FamilyKhataApp.kt"
THEME="app/src/main/java/com/familykhata/app/ui/HisabiKhataTheme.kt"
GRADLE="app/build.gradle.kts"
WORKFLOW=".github/workflows/android-build.yml"
PAYLOAD="v1.1_payload"

require_blob() {
  local path="$1"
  local expected="$2"
  test -f "$path" || { echo "ERROR: missing $path" >&2; exit 1; }
  local actual
  actual="$(git hash-object "$path")"
  test "$actual" = "$expected" || {
    echo "ERROR: $path is not the verified v1.0 baseline." >&2
    echo "Expected: $expected" >&2
    echo "Actual:   $actual" >&2
    exit 1
  }
}

require_blob "$UI" "94fcd5e101be10641bcb5f6a4ab649ed0b0b4319"
require_blob "$THEME" "8370734fbfc61d569ca657f98dea6479a31f3d88"
require_blob "$GRADLE" "563d04082373cc9479bbdcda0a927477fc5f925f"
require_blob "$WORKFLOW" "16ae7fa85ac0f40a916c104565fba00384657e24"

test -d "$PAYLOAD" || { echo "ERROR: payload folder missing" >&2; exit 1; }

cp "$PAYLOAD/$UI" "$UI"
cp "$PAYLOAD/$THEME" "$THEME"
cp "$PAYLOAD/$GRADLE" "$GRADLE"
cp "$PAYLOAD/$WORKFLOW" "$WORKFLOW"
rm -rf "$PAYLOAD"

# Final integrity checks for the intended v1.1 files.
test "$(git hash-object "$UI")" = "b1172cbb32a8d2357506903825ff0316b00e9788"
test "$(git hash-object "$THEME")" = "68de11d79d05083022dd53283d7ab142cd6e82eb"
test "$(git hash-object "$GRADLE")" = "21c004914e8e0bbcf1c770ef194d6579f4409962"
test "$(git hash-object "$WORKFLOW")" = "5096cba2782d8b741cf1bd97e54c9a9d9683ffd0"

echo "v1.1 visual polish applied"
