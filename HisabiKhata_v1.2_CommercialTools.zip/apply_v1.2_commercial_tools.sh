#!/usr/bin/env bash
set -euo pipefail

ROOT="$(git rev-parse --show-toplevel)"
cd "$ROOT"

check_blob() {
  local path="$1"
  local expected="$2"
  local actual
  actual="$(git hash-object "$path")"
  if [[ "$actual" != "$expected" ]]; then
    echo "ERROR: $path baseline mismatch"
    echo "Expected: $expected"
    echo "Actual:   $actual"
    echo "Stop here; do not commit."
    exit 1
  fi
}

check_blob "app/src/main/java/com/familykhata/app/ui/FamilyKhataApp.kt" "b1172cbb32a8d2357506903825ff0316b00e9788"
check_blob "app/src/main/java/com/familykhata/app/FamilyKhataViewModel.kt" "c8f3e1dd318a102a13ab0576e675b3d3864f854a"
check_blob "app/src/main/java/com/familykhata/app/data/FamilyKhataDao.kt" "60d7697810236eaef2370b9a45d7766bc33404ff"
check_blob "app/build.gradle.kts" "21c004914e8e0bbcf1c770ef194d6579f4409962"
check_blob ".github/workflows/android-build.yml" "5096cba2782d8b741cf1bd97e54c9a9d9683ffd0"
check_blob "docs/privacy.html" "b1b6819ed337f23345e85c391a7d729ba629cdf3"
check_blob "docs/index.html" "99fa8d7a66bc914e8e13c44ee6d183ae60e7449c"

test ! -e app/src/main/java/com/familykhata/app/ui/CommercialFeatures.kt || {
  echo "ERROR: CommercialFeatures.kt already exists"; exit 1;
}

test -s v1.2_payload/app/src/main/java/com/familykhata/app/ui/CommercialFeatures.kt
test -s v1.2_payload/docs/privacy.html
test -s v1.2_payload/docs/index.html

python3 <<'PY'
from pathlib import Path


buffers = {}

def replace_once(path, old, new, label):
    text = buffers.get(path)
    if text is None:
        text = Path(path).read_text(encoding="utf-8")
    count = text.count(old)
    if count != 1:
        raise SystemExit(f"ERROR: {label}: expected exactly 1 match in {path}, found {count}")
    buffers[path] = text.replace(old, new, 1)

# ---------------- DAO: edit/delete person without schema change ----------------
path = "app/src/main/java/com/familykhata/app/data/FamilyKhataDao.kt"
replace_once(
    path,
    '''    @Insert(onConflict = OnConflictStrategy.REPLACE)\n    suspend fun insertPerson(person: BakiPersonEntity): Long\n\n    @Insert(onConflict = OnConflictStrategy.REPLACE)\n    suspend fun insertBakiEntry(entry: BakiEntryEntity)\n''',
    '''    @Insert(onConflict = OnConflictStrategy.REPLACE)\n    suspend fun insertPerson(person: BakiPersonEntity): Long\n\n    @Query("UPDATE baki_people SET name = :name, phone = :phone WHERE id = :personId")\n    suspend fun updatePerson(personId: Long, name: String, phone: String)\n\n    @Query("DELETE FROM baki_people WHERE id = :personId")\n    suspend fun deletePersonById(personId: Long)\n\n    @Insert(onConflict = OnConflictStrategy.REPLACE)\n    suspend fun insertBakiEntry(entry: BakiEntryEntity)\n''',
    "DAO person edit/delete"
)

# ---------------- ViewModel: trial, PIN lock, reports, person edit/delete ----------------
path = "app/src/main/java/com/familykhata/app/FamilyKhataViewModel.kt"
replace_once(
    path,
    '''import org.json.JSONArray\nimport org.json.JSONObject\n\n@OptIn(ExperimentalCoroutinesApi::class)\n''',
    '''import org.json.JSONArray\nimport org.json.JSONObject\nimport java.security.MessageDigest\nimport java.security.SecureRandom\nimport java.text.SimpleDateFormat\nimport java.util.Calendar\nimport java.util.Date\nimport java.util.Locale\n\nprivate const val TRIAL_DAYS = 30\nprivate const val DAY_MS = 86_400_000L\n\ndata class TrialStatus(\n    val trialDays: Int,\n    val daysRemaining: Int,\n    val expired: Boolean,\n    val premiumUnlocked: Boolean,\n    val startedAt: Long,\n    val expiresAt: Long\n)\n\n@OptIn(ExperimentalCoroutinesApi::class)\n''',
    "ViewModel imports and TrialStatus"
)

replace_once(
    path,
    '''    private val preferences = application.getSharedPreferences(\n        "hisabi_khata_preferences",\n        Context.MODE_PRIVATE\n    )\n\n    private val allowedWorkspaces = setOf("PERSONAL", "FAMILY", "SHOP")\n''',
    '''    private val preferences = application.getSharedPreferences(\n        "hisabi_khata_preferences",\n        Context.MODE_PRIVATE\n    )\n\n    private val trialStartedAt: Long = preferences.getLong("trial_started_at", 0L).let { saved ->\n        if (saved > 0L) saved else System.currentTimeMillis().also { started ->\n            preferences.edit().putLong("trial_started_at", started).apply()\n        }\n    }\n    private val _trialStatus = MutableStateFlow(calculateTrialStatus())\n    val trialStatus: StateFlow<TrialStatus> = _trialStatus.asStateFlow()\n\n    private val _isPinConfigured = MutableStateFlow(\n        !preferences.getString("pin_hash", null).isNullOrBlank() &&\n            !preferences.getString("pin_salt", null).isNullOrBlank()\n    )\n    val isPinConfigured: StateFlow<Boolean> = _isPinConfigured.asStateFlow()\n\n    private val _isAppUnlocked = MutableStateFlow(!_isPinConfigured.value)\n    val isAppUnlocked: StateFlow<Boolean> = _isAppUnlocked.asStateFlow()\n\n    private val allowedWorkspaces = setOf("PERSONAL", "FAMILY", "SHOP")\n''',
    "ViewModel commercial state"
)

replace_once(
    path,
    '''    fun addTransaction(type: String, amount: Double, category: String, note: String) {\n        if (amount <= 0) return\n''',
    '''    fun addTransaction(type: String, amount: Double, category: String, note: String) {\n        if (!canWriteNow() || amount <= 0) return\n''',
    "trial guard transaction"
)

replace_once(
    path,
    '''    fun addBakiPerson(name: String, phone: String) {\n        if (name.isBlank()) return\n''',
    '''    fun addBakiPerson(name: String, phone: String) {\n        if (!canWriteNow() || name.isBlank()) return\n''',
    "trial guard person"
)

replace_once(
    path,
    '''    fun addBakiEntry(personId: Long, action: String, amount: Double, note: String) {\n        if (amount <= 0) return\n''',
    '''    fun addBakiEntry(personId: Long, action: String, amount: Double, note: String) {\n        if (!canWriteNow() || amount <= 0) return\n''',
    "trial guard baki entry"
)

replace_once(
    path,
    '''    fun addBakiEntry(personId: Long, action: String, amount: Double, note: String) {\n''',
    '''    fun updateBakiPerson(personId: Long, name: String, phone: String) {\n        val cleanName = name.trim()\n        if (!canWriteNow() || cleanName.isBlank()) return\n        viewModelScope.launch {\n            dao.updatePerson(personId, cleanName, phone.trim())\n        }\n    }\n\n    fun deleteBakiPerson(personId: Long) {\n        viewModelScope.launch { dao.deletePersonById(personId) }\n    }\n\n    fun addBakiEntry(personId: Long, action: String, amount: Double, note: String) {\n''',
    "person edit/delete methods"
)

commercial_methods = r'''
    fun refreshTrialStatus() {
        _trialStatus.value = calculateTrialStatus()
    }

    private fun calculateTrialStatus(now: Long = System.currentTimeMillis()): TrialStatus {
        val premiumUnlocked = preferences.getBoolean("premium_unlocked", false)
        val expiresAt = trialStartedAt + TRIAL_DAYS * DAY_MS
        val remainingMillis = (expiresAt - now).coerceAtLeast(0L)
        val daysRemaining = if (premiumUnlocked) {
            TRIAL_DAYS
        } else if (remainingMillis == 0L) {
            0
        } else {
            ((remainingMillis + DAY_MS - 1L) / DAY_MS).toInt()
        }
        return TrialStatus(
            trialDays = TRIAL_DAYS,
            daysRemaining = daysRemaining,
            expired = !premiumUnlocked && now >= expiresAt,
            premiumUnlocked = premiumUnlocked,
            startedAt = trialStartedAt,
            expiresAt = expiresAt
        )
    }

    private fun canWriteNow(): Boolean {
        val current = calculateTrialStatus()
        _trialStatus.value = current
        return !current.expired
    }

    fun setPin(pin: String): Boolean {
        if (!pin.matches(Regex("^\\d{4,6}$"))) return false
        val salt = randomSalt()
        preferences.edit()
            .putString("pin_salt", salt)
            .putString("pin_hash", hashPin(pin, salt))
            .apply()
        _isPinConfigured.value = true
        _isAppUnlocked.value = true
        return true
    }

    fun verifyPin(pin: String): Boolean {
        if (!_isPinConfigured.value) {
            _isAppUnlocked.value = true
            return true
        }
        val ok = matchesStoredPin(pin)
        if (ok) _isAppUnlocked.value = true
        return ok
    }

    fun changePin(currentPin: String, newPin: String): Boolean {
        if (!matchesStoredPin(currentPin) || !newPin.matches(Regex("^\\d{4,6}$"))) return false
        val salt = randomSalt()
        preferences.edit()
            .putString("pin_salt", salt)
            .putString("pin_hash", hashPin(newPin, salt))
            .apply()
        _isPinConfigured.value = true
        _isAppUnlocked.value = true
        return true
    }

    fun disablePin(currentPin: String): Boolean {
        if (!matchesStoredPin(currentPin)) return false
        preferences.edit()
            .remove("pin_salt")
            .remove("pin_hash")
            .apply()
        _isPinConfigured.value = false
        _isAppUnlocked.value = true
        return true
    }

    fun lockApp() {
        if (_isPinConfigured.value) _isAppUnlocked.value = false
    }

    private fun matchesStoredPin(pin: String): Boolean {
        val salt = preferences.getString("pin_salt", null) ?: return false
        val storedHash = preferences.getString("pin_hash", null) ?: return false
        return hashPin(pin, salt) == storedHash
    }

    private fun randomSalt(): String {
        val bytes = ByteArray(16)
        SecureRandom().nextBytes(bytes)
        return bytes.joinToString("") { byte -> "%02x".format(byte.toInt() and 0xff) }
    }

    private fun hashPin(pin: String, salt: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest("$salt:$pin".toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { byte -> "%02x".format(byte.toInt() and 0xff) }
    }

    fun createCsvReport(
        period: String,
        onReady: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            runCatching {
                require(period in setOf("MONTH", "YEAR", "ALL")) { "রিপোর্ট সময়সীমা সঠিক নয়" }
                val now = System.currentTimeMillis()
                val startAt = reportStart(period, now)
                val workspace = _selectedWorkspace.value

                val people = dao.getAllPeople().filter { it.workspace == workspace }
                val personMap = people.associateBy { it.id }
                val personIds = personMap.keys
                val rows = mutableListOf<Pair<Long, List<String>>>()

                dao.getAllTransactions()
                    .asSequence()
                    .filter { it.workspace == workspace && it.createdAt in startAt..now }
                    .forEach { item ->
                        rows += item.createdAt to listOf(
                            formatReportDate(item.createdAt),
                            "আয়-খরচ",
                            item.category,
                            if (item.type == "INCOME") "আয়" else "খরচ",
                            item.amount.toString(),
                            item.note
                        )
                    }

                dao.getAllBakiEntries()
                    .asSequence()
                    .filter { it.personId in personIds && it.createdAt in startAt..now }
                    .forEach { entry ->
                        rows += entry.createdAt to listOf(
                            formatReportDate(entry.createdAt),
                            "বাকি/পাওনা",
                            personMap[entry.personId]?.name.orEmpty(),
                            reportActionLabel(entry.action),
                            entry.amount.toString(),
                            entry.note
                        )
                    }

                buildString {
                    append('\uFEFF')
                    appendLine("তারিখ,ধরন,ব্যক্তি/ক্যাটাগরি,লেনদেন,টাকা,নোট")
                    rows.sortedByDescending { it.first }.forEach { (_, columns) ->
                        appendLine(columns.joinToString(",") { csvEscape(it) })
                    }
                }
            }.onSuccess(onReady).onFailure {
                onError(it.message ?: "রিপোর্ট তৈরি করা যায়নি")
            }
        }
    }

    private fun reportStart(period: String, now: Long): Long {
        if (period == "ALL") return 0L
        return Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (period == "MONTH") {
                set(Calendar.DAY_OF_MONTH, 1)
            } else {
                set(Calendar.MONTH, Calendar.JANUARY)
                set(Calendar.DAY_OF_MONTH, 1)
            }
        }.timeInMillis
    }

    private fun csvEscape(value: String): String =
        "\"" + value.replace("\"", "\"\"") + "\""

    private fun formatReportDate(timestamp: Long): String =
        SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(timestamp))

    private fun reportActionLabel(action: String): String = when (action) {
        "GAVE" -> "দিলাম"
        "RECEIVED_BACK" -> "ফেরত পেলাম"
        "TOOK" -> "নিলাম"
        "PAID_BACK" -> "ফেরত দিলাম"
        else -> action
    }

'''
replace_once(
    path,
    '''\n\n    fun createBackup(\n''',
    '\n\n' + commercial_methods + '    fun createBackup(\n',
    "commercial methods before backup"
)

# ---------------- UI: gate, trial UI, search, person color, person management ----------------
path = "app/src/main/java/com/familykhata/app/ui/FamilyKhataApp.kt"
replace_once(path, '"v1.1 • Visual Polish"', '"v1.2 • Commercial Tools"', "header version")
replace_once(path, 'Text("হিসাবী খাতা v1.1", fontWeight = FontWeight.Bold)', 'Text("হিসাবী খাতা v1.2", fontWeight = FontWeight.Bold)', "about version")

replace_once(
    path,
    '''    val workspace by viewModel.selectedWorkspace.collectAsState()\n\n    HisabiKhataTheme {\n        Scaffold(\n''',
    '''    val workspace by viewModel.selectedWorkspace.collectAsState()\n    val trialStatus by viewModel.trialStatus.collectAsState()\n    val isAppUnlocked by viewModel.isAppUnlocked.collectAsState()\n\n    HisabiKhataTheme {\n        if (!isAppUnlocked) {\n            AppLockScreen(viewModel)\n        } else {\n            Scaffold(\n''',
    "root commercial state"
)

replace_once(
    path,
    '''                )\n                Spacer(Modifier.height(12.dp))\n                Box(\n''',
    '''                )\n                Spacer(Modifier.height(8.dp))\n                TrialNotice(trialStatus)\n                Spacer(Modifier.height(12.dp))\n                Box(\n''',
    "trial notice"
)

replace_once(
    path,
    '''                        Tab.ADD -> AddTransactionScreen(\n                            viewModel = viewModel,\n                            workspace = workspace,\n                            initialType = addTypePreset\n                        )\n                        Tab.BAKI -> BakiScreen(viewModel, workspace)\n''',
    '''                        Tab.ADD -> AddTransactionScreen(\n                            viewModel = viewModel,\n                            workspace = workspace,\n                            initialType = addTypePreset,\n                            canWrite = !trialStatus.expired\n                        )\n                        Tab.BAKI -> BakiScreen(viewModel, workspace, canWrite = !trialStatus.expired)\n''',
    "pass trial write access"
)

replace_once(
    path,
    '''        }\n    }\n}\n\n@Composable\nprivate fun BrandHeader''',
    '''        }\n        }\n    }\n}\n\n@Composable\nprivate fun BrandHeader''',
    "close app lock else"
)

replace_once(
    path,
    '''private fun AddTransactionScreen(\n    viewModel: FamilyKhataViewModel,\n    workspace: String,\n    initialType: String\n) {\n''',
    '''private fun AddTransactionScreen(\n    viewModel: FamilyKhataViewModel,\n    workspace: String,\n    initialType: String,\n    canWrite: Boolean\n) {\n''',
    "AddTransaction signature"
)

replace_once(
    path,
    '''        if (isBusiness) {\n            Text(\n                "দোকান/প্রতিষ্ঠানের টাকা আসা বা বের হওয়ার হিসাব যোগ করুন।",\n                style = MaterialTheme.typography.bodySmall\n            )\n        }\n\n        Row(\n''',
    '''        if (isBusiness) {\n            Text(\n                "দোকান/প্রতিষ্ঠানের টাকা আসা বা বের হওয়ার হিসাব যোগ করুন।",\n                style = MaterialTheme.typography.bodySmall\n            )\n        }\n        if (!canWrite) {\n            TrialLockedMessage()\n        }\n\n        Row(\n''',
    "AddTransaction locked notice"
)

replace_once(
    path,
    '''            },\n            modifier = Modifier.fillMaxWidth()\n        ) { Text(if (isBusiness) "ক্যাশ লেনদেন সেভ করুন" else "সেভ করুন") }\n''',
    '''            },\n            modifier = Modifier.fillMaxWidth(),\n            enabled = canWrite\n        ) { Text(if (isBusiness) "ক্যাশ লেনদেন সেভ করুন" else "সেভ করুন") }\n''',
    "AddTransaction save disabled"
)

replace_once(
    path,
    '''private fun BakiScreen(viewModel: FamilyKhataViewModel, workspace: String) {\n''',
    '''private fun BakiScreen(viewModel: FamilyKhataViewModel, workspace: String, canWrite: Boolean) {\n''',
    "BakiScreen signature"
)

replace_once(
    path,
    '''            workspace = workspace,\n            onSelect = { selectedId = it.id }\n''',
    '''            workspace = workspace,\n            canWrite = canWrite,\n            onSelect = { selectedId = it.id }\n''',
    "Baki people canWrite"
)

replace_once(
    path,
    '''            workspace = workspace,\n            onBack = { selectedId = null }\n''',
    '''            workspace = workspace,\n            canWrite = canWrite,\n            onBack = { selectedId = null }\n''',
    "Baki entry canWrite"
)

replace_once(
    path,
    '''private fun BakiPeopleScreen(\n    people: List<BakiPersonSummary>,\n    viewModel: FamilyKhataViewModel,\n    workspace: String,\n    onSelect: (BakiPersonSummary) -> Unit\n) {\n    var name by remember { mutableStateOf("") }\n    var phone by remember { mutableStateOf("") }\n''',
    '''private fun BakiPeopleScreen(\n    people: List<BakiPersonSummary>,\n    viewModel: FamilyKhataViewModel,\n    workspace: String,\n    canWrite: Boolean,\n    onSelect: (BakiPersonSummary) -> Unit\n) {\n    var name by remember { mutableStateOf("") }\n    var phone by remember { mutableStateOf("") }\n    var query by remember { mutableStateOf("") }\n''',
    "Baki people signature/search state"
)

replace_once(
    path,
    '''            },\n            modifier = Modifier.fillMaxWidth()\n        ) { Text("$personLabel যোগ করুন") }\n\n        Spacer(Modifier.height(4.dp))\n        Text(sectionTitle, fontWeight = FontWeight.Bold)\n\n        if (people.isEmpty()) {\n            Text("প্রথমে একজন $personLabel যোগ করুন।")\n        } else {\n            people.forEach { person ->\n                val accent = balanceAccent(person.balance)\n''',
    '''            },\n            modifier = Modifier.fillMaxWidth(),\n            enabled = canWrite\n        ) { Text("$personLabel যোগ করুন") }\n\n        if (!canWrite) {\n            TrialLockedMessage()\n        }\n\n        Spacer(Modifier.height(4.dp))\n        Text(sectionTitle, fontWeight = FontWeight.Bold)\n\n        if (people.isNotEmpty()) {\n            OutlinedTextField(\n                value = query,\n                onValueChange = { query = it },\n                label = { Text("নাম বা ফোন দিয়ে খুঁজুন") },\n                singleLine = true,\n                modifier = Modifier.fillMaxWidth()\n            )\n        }\n        val filteredPeople = people.filter { person ->\n            query.isBlank() || person.name.contains(query, ignoreCase = true) || person.phone.contains(query)\n        }\n\n        if (people.isEmpty()) {\n            Text("প্রথমে একজন $personLabel যোগ করুন।")\n        } else if (filteredPeople.isEmpty()) {\n            Text("এই নামে বা ফোন নম্বরে কাউকে পাওয়া যায়নি।")\n        } else {\n            filteredPeople.forEach { person ->\n                val personTone = personAccent(person.id)\n                val balanceTone = balanceAccent(person.balance)\n''',
    "Baki people search and add guard"
)

replace_once(
    path,
    '''                    colors = CardDefaults.cardColors(\n                        containerColor = accent.copy(alpha = 0.08f)\n                    ),\n                    border = BorderStroke(1.dp, accent.copy(alpha = 0.20f))\n''',
    '''                    colors = CardDefaults.cardColors(\n                        containerColor = personTone.copy(alpha = 0.10f)\n                    ),\n                    border = BorderStroke(1.dp, personTone.copy(alpha = 0.24f))\n''',
    "person card unique tone"
)

replace_once(
    path,
    '''                        Text(\n                            person.name,\n                            fontWeight = FontWeight.Bold,\n                            style = MaterialTheme.typography.titleMedium\n                        )\n''',
    '''                        Text(\n                            person.name,\n                            fontWeight = FontWeight.ExtraBold,\n                            style = MaterialTheme.typography.titleMedium,\n                            color = personTone\n                        )\n''',
    "person name unique tone"
)

replace_once(
    path,
    '''                            fontWeight = FontWeight.Bold,\n                            color = accent\n                        )\n                        Text(\n                            if (workspace == "SHOP") "খাতা ও লেনদেন দেখতে চাপুন" else "হিসাব ও ইতিহাস দেখতে চাপুন",\n''',
    '''                            fontWeight = FontWeight.Bold,\n                            color = balanceTone\n                        )\n                        Text(\n                            if (workspace == "SHOP") "খাতা ও লেনদেন দেখতে চাপুন" else "হিসাব ও ইতিহাস দেখতে চাপুন",\n''',
    "person balance tone"
)

replace_once(
    path,
    '''private fun BakiEntryScreen(\n    person: BakiPersonSummary,\n    viewModel: FamilyKhataViewModel,\n    workspace: String,\n    onBack: () -> Unit\n) {\n''',
    '''private fun BakiEntryScreen(\n    person: BakiPersonSummary,\n    viewModel: FamilyKhataViewModel,\n    workspace: String,\n    canWrite: Boolean,\n    onBack: () -> Unit\n) {\n''',
    "BakiEntry signature"
)

replace_once(
    path,
    '''        Text(person.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)\n''',
    '''        Text(\n            person.name,\n            style = MaterialTheme.typography.headlineSmall,\n            fontWeight = FontWeight.ExtraBold,\n            color = personAccent(person.id)\n        )\n''',
    "detail person color"
)

replace_once(
    path,
    '''        }\n\n        if (person.phone.isNotBlank()) {\n''',
    '''        }\n\n        PersonManagementActions(\n            person = person,\n            personLabel = if (workspace == "SHOP") "কাস্টমার/সাপ্লায়ার" else "ব্যক্তি",\n            canWrite = canWrite,\n            viewModel = viewModel,\n            onDeleted = onBack\n        )\n\n        if (person.phone.isNotBlank()) {\n''',
    "person management actions"
)

replace_once(
    path,
    '''        Text("নতুন এন্ট্রি", fontWeight = FontWeight.Bold)\n''',
    '''        if (!canWrite) {\n            TrialLockedMessage()\n        }\n        Text("নতুন এন্ট্রি", fontWeight = FontWeight.Bold)\n''',
    "Baki entry locked notice"
)

replace_once(
    path,
    '''            },\n            modifier = Modifier.fillMaxWidth()\n        ) { Text(if (workspace == "SHOP") "খাতার এন্ট্রি সেভ করুন" else "বাকি এন্ট্রি সেভ করুন") }\n''',
    '''            },\n            modifier = Modifier.fillMaxWidth(),\n            enabled = canWrite\n        ) { Text(if (workspace == "SHOP") "খাতার এন্ট্রি সেভ করুন" else "বাকি এন্ট্রি সেভ করুন") }\n''',
    "Baki entry save disabled"
)

replace_once(
    path,
    '''        Text(\n            "ডেটা নিরাপত্তা, শেয়ার, সাপোর্ট ও অ্যাপ সম্পর্কিত প্রয়োজনীয় অপশন।",\n            style = MaterialTheme.typography.bodyMedium\n        )\n\n        MoreSectionTitle("ডেটা নিরাপত্তা")\n''',
    '''        Text(\n            "ডেটা নিরাপত্তা, শেয়ার, সাপোর্ট ও অ্যাপ সম্পর্কিত প্রয়োজনীয় অপশন।",\n            style = MaterialTheme.typography.bodyMedium\n        )\n\n        CommercialToolsSection(viewModel)\n\n        MoreSectionTitle("ডেটা নিরাপত্তা")\n''',
    "commercial tools in More"
)

# ---------------- Version/build artifacts ----------------
replace_once("app/build.gradle.kts", 'versionCode = 12', 'versionCode = 13', "versionCode")
replace_once("app/build.gradle.kts", 'versionName = "1.1.0"', 'versionName = "1.2.0"', "versionName")
replace_once(".github/workflows/android-build.yml", 'HisabiKhata-v1.1-play-aab', 'HisabiKhata-v1.2-play-aab', "AAB artifact name")
replace_once(".github/workflows/android-build.yml", 'HisabiKhata-v1.1-direct-apk', 'HisabiKhata-v1.2-direct-apk', "APK artifact name")

for output_path, content in buffers.items():
    Path(output_path).write_text(content, encoding="utf-8")
PY

cp v1.2_payload/app/src/main/java/com/familykhata/app/ui/CommercialFeatures.kt \
  app/src/main/java/com/familykhata/app/ui/CommercialFeatures.kt
cp v1.2_payload/docs/privacy.html docs/privacy.html
cp v1.2_payload/docs/index.html docs/index.html
rm -rf v1.2_payload

git diff --check

echo "v1.2 commercial tools applied"
