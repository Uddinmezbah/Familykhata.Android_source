Hisabi Khata v1.4 Combined Upgrade

- Start from the stable v1.2 main branch.
- Do NOT apply/push v1.3 first.
- v1.4 incorporates v1.3 due-date/customer/commercial work plus the new top-left settings menu, profile, premium contact, PIN management, due reminders, currency display, summary privacy, WhatsApp/SMS/Call actions, tutorial link and support shortcuts.

Apply:
  unzip -o HisabiKhata_v1.4_CompleteUpgrade.zip
  bash apply_v1.4.sh

Review git diff before commit/push.
