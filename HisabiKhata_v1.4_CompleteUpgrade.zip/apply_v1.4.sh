#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-.}"
cd "$ROOT"

required=(
  "app/src/main/java/com/familykhata/app/data/Models.kt"
  "app/src/main/java/com/familykhata/app/data/AppDatabase.kt"
  "app/src/main/java/com/familykhata/app/data/FamilyKhataDao.kt"
  "app/src/main/java/com/familykhata/app/FamilyKhataViewModel.kt"
  "app/src/main/java/com/familykhata/app/ui/FamilyKhataApp.kt"
  "app/build.gradle.kts"
  ".github/workflows/android-build.yml"
)
for f in "${required[@]}"; do
  test -f "$f" || { echo "ERROR: missing $f"; exit 1; }
done

cat > app/src/main/java/com/familykhata/app/data/Models.kt <<'EOF'
package com.familykhata.app.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String, // INCOME or EXPENSE
    val amount: Double,
    val category: String,
    val note: String,
    @ColumnInfo(defaultValue = "'FAMILY'") val workspace: String = "FAMILY",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "baki_people")
data class BakiPersonEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = "",
    val note: String = "",
    @ColumnInfo(defaultValue = "'FAMILY'") val workspace: String = "FAMILY",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "baki_entries",
    foreignKeys = [
        ForeignKey(
            entity = BakiPersonEntity::class,
            parentColumns = ["id"],
            childColumns = ["personId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("personId")]
)
data class BakiEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val personId: Long,
    val action: String, // GAVE, RECEIVED_BACK, TOOK, PAID_BACK
    val amount: Double,
    val balanceDelta: Double,
    val note: String = "",
    val dueAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

data class DashboardTotals(
    val income: Double,
    val expense: Double
)

data class BakiPersonSummary(
    val id: Long,
    val name: String,
    val phone: String,
    val balance: Double
)

data class DueReceivableItem(
    val entryId: Long,
    val personId: Long,
    val personName: String,
    val phone: String,
    val originalAmount: Double,
    val remainingAmount: Double,
    val dueAt: Long,
    val note: String
)
EOF

cat > app/src/main/java/com/familykhata/app/data/AppDatabase.kt <<'EOF'
package com.familykhata.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [TransactionEntity::class, BakiPersonEntity::class, BakiEntryEntity::class],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): FamilyKhataDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE transactions ADD COLUMN workspace TEXT NOT NULL DEFAULT 'FAMILY'"
                )
                db.execSQL(
                    "ALTER TABLE baki_people ADD COLUMN workspace TEXT NOT NULL DEFAULT 'FAMILY'"
                )
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE baki_entries ADD COLUMN dueAt INTEGER")
            }
        }

        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "family-khata.db"
            )
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                .build()
                .also { INSTANCE = it }
        }
    }
}
EOF

cat > app/src/main/java/com/familykhata/app/data/FamilyKhataDao.kt <<'EOF'
package com.familykhata.app.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface FamilyKhataDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(item: TransactionEntity)

    @Delete
    suspend fun deleteTransaction(item: TransactionEntity)

    @Query("SELECT * FROM transactions WHERE workspace = :workspace ORDER BY createdAt DESC")
    fun observeTransactions(workspace: String): Flow<List<TransactionEntity>>

    @Query(
        """
        SELECT
            COALESCE(SUM(CASE WHEN type = 'INCOME' THEN amount ELSE 0 END), 0) AS income,
            COALESCE(SUM(CASE WHEN type = 'EXPENSE' THEN amount ELSE 0 END), 0) AS expense
        FROM transactions
        WHERE workspace = :workspace
        """
    )
    fun observeDashboardTotals(workspace: String): Flow<DashboardTotals>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPerson(person: BakiPersonEntity): Long

    @Query("UPDATE baki_people SET name = :name, phone = :phone WHERE id = :personId")
    suspend fun updatePerson(personId: Long, name: String, phone: String)

    @Query("DELETE FROM baki_people WHERE id = :personId")
    suspend fun deletePersonById(personId: Long)

    @Query("SELECT * FROM baki_people WHERE workspace = :workspace ORDER BY name COLLATE NOCASE ASC")
    fun observePeople(workspace: String): Flow<List<BakiPersonEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBakiEntry(entry: BakiEntryEntity)

    @Delete
    suspend fun deleteBakiEntry(entry: BakiEntryEntity)

    @Query(
        """
        UPDATE baki_entries
        SET amount = :amount,
            balanceDelta = :balanceDelta,
            note = :note,
            dueAt = :dueAt
        WHERE id = :entryId
        """
    )
    suspend fun updateBakiEntry(
        entryId: Long,
        amount: Double,
        balanceDelta: Double,
        note: String,
        dueAt: Long?
    )

    @Query(
        """
        SELECT p.id AS id, p.name AS name, p.phone AS phone,
               COALESCE(SUM(e.balanceDelta), 0) AS balance
        FROM baki_people p
        LEFT JOIN baki_entries e ON p.id = e.personId
        WHERE p.workspace = :workspace
        GROUP BY p.id
        ORDER BY p.name COLLATE NOCASE ASC
        """
    )
    fun observeBakiSummaries(workspace: String): Flow<List<BakiPersonSummary>>

    @Query("SELECT * FROM baki_entries WHERE personId = :personId ORDER BY createdAt DESC")
    fun observeBakiEntries(personId: Long): Flow<List<BakiEntryEntity>>

    @Query(
        """
        SELECT e.*
        FROM baki_entries e
        INNER JOIN baki_people p ON p.id = e.personId
        WHERE p.workspace = :workspace
        ORDER BY e.createdAt ASC, e.id ASC
        """
    )
    fun observeWorkspaceBakiEntries(workspace: String): Flow<List<BakiEntryEntity>>

    @Query("SELECT * FROM transactions ORDER BY id ASC")
    suspend fun getAllTransactions(): List<TransactionEntity>

    @Query("SELECT * FROM baki_people ORDER BY id ASC")
    suspend fun getAllPeople(): List<BakiPersonEntity>

    @Query("SELECT * FROM baki_entries ORDER BY id ASC")
    suspend fun getAllBakiEntries(): List<BakiEntryEntity>

    @Query("DELETE FROM baki_entries")
    suspend fun clearBakiEntries()

    @Query("DELETE FROM baki_people")
    suspend fun clearPeople()

    @Query("DELETE FROM transactions")
    suspend fun clearTransactions()
}
EOF

cat > app/src/main/java/com/familykhata/app/ui/V13Features.kt <<'EOF'
package com.familykhata.app.ui

import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.familykhata.app.FamilyKhataViewModel
import com.familykhata.app.data.BakiEntryEntity
import com.familykhata.app.data.BakiPersonSummary
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private const val V13_WEBSITE = "https://uddinmezbah.github.io/Familykhata.Android_source/"
private const val V13_TUTORIAL = "https://uddinmezbah.github.io/Familykhata.Android_source/#tutorial"
private val DueTodayAccent = Color(0xFF0B7A53)
private val OverdueAccent = Color(0xFFC4473A)
private val PlanAccent = Color(0xFF6C4CCF)

@Composable
internal fun DueDatePickerField(
    value: Long?,
    onChange: (Long?) -> Unit,
    label: String = "পরিশোধের তারিখ"
) {
    val context = LocalContext.current
    val calendar = remember(value) {
        Calendar.getInstance().apply {
            if (value != null) timeInMillis = value
        }
    }
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        OutlinedButton(
            onClick = {
                DatePickerDialog(
                    context,
                    { _, year, month, day ->
                        val selected = Calendar.getInstance().apply {
                            clear()
                            set(year, month, day, 0, 0, 0)
                        }.timeInMillis
                        onChange(selected)
                    },
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
                ).show()
            },
            modifier = Modifier.weight(1f)
        ) {
            Text(if (value == null) "$label নির্বাচন করুন" else "$label: ${v13Date(value)}")
        }
        if (value != null) {
            TextButton(onClick = { onChange(null) }) { Text("মুছুন") }
        }
    }
}

@Composable
internal fun DueDashboardSection(
    viewModel: FamilyKhataViewModel,
    onLedger: () -> Unit
) {
    val items by viewModel.dueReceivables.collectAsState()
    val todayStart = startOfToday()
    val tomorrowStart = todayStart + 86_400_000L
    val today = items.filter { it.dueAt in todayStart until tomorrowStart }
    val overdue = items.filter { it.dueAt < todayStart }
    val todayAmount = today.sumOf { it.remainingAmount }
    val overdueAmount = overdue.sumOf { it.remainingAmount }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        DueMetricCard(
            title = "আজকে পাবো",
            amount = todayAmount,
            count = today.size,
            accent = DueTodayAccent,
            modifier = Modifier.weight(1f),
            onClick = onLedger
        )
        DueMetricCard(
            title = "বকেয়া",
            amount = overdueAmount,
            count = overdue.size,
            accent = OverdueAccent,
            modifier = Modifier.weight(1f),
            onClick = onLedger
        )
    }
}

@Composable
private fun DueMetricCard(
    title: String,
    amount: Double,
    count: Int,
    accent: Color,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = accent.copy(alpha = 0.09f)),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.24f)),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(title, fontWeight = FontWeight.Bold, color = accent)
            Text("৳ ${v13Money(amount)}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
            Text("$count টি এন্ট্রি", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
internal fun BakiEntryActionRow(
    person: BakiPersonSummary,
    item: BakiEntryEntity,
    canWrite: Boolean,
    viewModel: FamilyKhataViewModel,
    onDelete: () -> Unit
) {
    val context = LocalContext.current
    var showEdit by remember(item.id, item.amount, item.note, item.dueAt) { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            OutlinedButton(
                onClick = { showEdit = true },
                enabled = canWrite,
                modifier = Modifier.weight(1f)
            ) { Text("Edit") }
            OutlinedButton(
                onClick = onDelete,
                enabled = canWrite,
                modifier = Modifier.weight(1f)
            ) { Text("Delete") }
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            OutlinedButton(
                onClick = { sendEntrySms(context, person, item) },
                enabled = person.phone.isNotBlank(),
                modifier = Modifier.weight(1f)
            ) { Text("SMS") }
            OutlinedButton(
                onClick = { callPerson(context, person.phone) },
                enabled = person.phone.isNotBlank(),
                modifier = Modifier.weight(1f)
            ) { Text("Call") }
        }
    }

    if (showEdit) {
        var amount by remember(item.id) { mutableStateOf(v13Money(item.amount)) }
        var note by remember(item.id) { mutableStateOf(item.note) }
        var dueAt by remember(item.id) { mutableStateOf(item.dueAt) }
        var error by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showEdit = false },
            title = { Text("এন্ট্রি সম্পাদনা") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = amount,
                        onValueChange = { amount = it; error = null },
                        label = { Text("টাকার পরিমাণ") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("নোট") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    DueDatePickerField(value = dueAt, onChange = { dueAt = it })
                    error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val parsed = v13ParseAmount(amount)
                    if (parsed == null) {
                        error = "সঠিক টাকার পরিমাণ লিখুন"
                    } else {
                        viewModel.updateBakiEntry(item, parsed, note, dueAt)
                        showEdit = false
                    }
                }) { Text("সেভ করুন") }
            },
            dismissButton = {
                TextButton(onClick = { showEdit = false }) { Text("বাতিল") }
            }
        )
    }
}

@Composable
internal fun PurchaseAndTutorialSection() {
    val context = LocalContext.current
    var selectedPlan by remember { mutableStateOf("মাসিক") }

    Text(
        "প্ল্যান ও সহায়তা",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
    )
    Text(
        "৩০ দিনের ট্রায়াল শেষে নতুন হিসাব যোগ/সম্পাদনার জন্য একটি প্ল্যান নিন। পুরনো ডেটা মুছে যাবে না।",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        listOf("মাসিক", "বার্ষিক", "Lifetime").forEach { plan ->
            val selected = selectedPlan == plan
            if (selected) {
                Button(
                    onClick = { selectedPlan = plan },
                    modifier = Modifier.weight(1f)
                ) { Text(plan) }
            } else {
                OutlinedButton(
                    onClick = { selectedPlan = plan },
                    modifier = Modifier.weight(1f)
                ) { Text(plan) }
            }
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = PlanAccent.copy(alpha = 0.07f)),
        border = BorderStroke(1.dp, PlanAccent.copy(alpha = 0.18f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("$selectedPlan প্ল্যান কিনতে যোগাযোগ করুন", fontWeight = FontWeight.Bold)
            Text(
                "দাম ও পেমেন্ট নির্দেশনা বিক্রয় চ্যানেলে জানানো হবে।",
                style = MaterialTheme.typography.bodySmall
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedButton(
                    onClick = { purchaseWhatsApp(context, selectedPlan) },
                    modifier = Modifier.weight(1f)
                ) { Text("WhatsApp") }
                OutlinedButton(
                    onClick = { purchaseMessenger(context, selectedPlan) },
                    modifier = Modifier.weight(1f)
                ) { Text("Messenger") }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedButton(
                    onClick = { purchaseSms(context, selectedPlan) },
                    modifier = Modifier.weight(1f)
                ) { Text("SMS") }
                OutlinedButton(
                    onClick = { v13OpenUrl(context, V13_WEBSITE) },
                    modifier = Modifier.weight(1f)
                ) { Text("Website") }
            }
        }
    }

    Card(
        onClick = { v13OpenUrl(context, V13_TUTORIAL) },
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = DueTodayAccent.copy(alpha = 0.07f)),
        border = BorderStroke(1.dp, DueTodayAccent.copy(alpha = 0.18f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text("▶ ব্যবহারের নিয়ম / ভিডিও", fontWeight = FontWeight.Bold)
            Text(
                "নতুন খাতা, বাকি, পরিশোধ, ব্যাকআপ ও রিপোর্ট ব্যবহারের গাইড দেখুন।",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

private fun sendEntrySms(context: Context, person: BakiPersonSummary, item: BakiEntryEntity) {
    val dueText = item.dueAt?.let { " পরিশোধের তারিখ ${v13Date(it)}।" }.orEmpty()
    val message = "আসসালামু আলাইকুম ${person.name}, হিসাবী খাতা অনুযায়ী ৳ ${v13Money(item.amount)} টাকার একটি হিসাব আছে.$dueText সুবিধামতো পরিশোধ/যোগাযোগ করার অনুরোধ রইল।"
    val intent = Intent(Intent.ACTION_SENDTO).apply {
        data = Uri.parse("smsto:${Uri.encode(person.phone)}")
        putExtra("sms_body", message)
    }
    runCatching { context.startActivity(intent) }
}

private fun callPerson(context: Context, phone: String) {
    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(phone)}"))
    runCatching { context.startActivity(intent) }
}

private fun purchaseMessage(plan: String): String =
    "আমি হিসাবী খাতা অ্যাপের $plan প্ল্যান নিতে চাই। পেমেন্ট ও অ্যাক্টিভেশন নির্দেশনা দিন।"

private fun purchaseWhatsApp(context: Context, plan: String) {
    val url = "https://wa.me/?text=${Uri.encode(purchaseMessage(plan))}"
    v13OpenUrl(context, url)
}

private fun purchaseMessenger(context: Context, plan: String) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, purchaseMessage(plan))
        setPackage("com.facebook.orca")
    }
    runCatching { context.startActivity(intent) }
        .recoverCatching {
            context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, purchaseMessage(plan))
            }, "যোগাযোগ করুন"))
        }
}

private fun purchaseSms(context: Context, plan: String) {
    val intent = Intent(Intent.ACTION_SENDTO).apply {
        data = Uri.parse("smsto:")
        putExtra("sms_body", purchaseMessage(plan))
    }
    runCatching { context.startActivity(intent) }
}

private fun v13OpenUrl(context: Context, url: String) {
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
}

private fun startOfToday(): Long = Calendar.getInstance().apply {
    set(Calendar.HOUR_OF_DAY, 0)
    set(Calendar.MINUTE, 0)
    set(Calendar.SECOND, 0)
    set(Calendar.MILLISECOND, 0)
}.timeInMillis

internal fun v13Date(timestamp: Long): String =
    SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(timestamp))

private fun v13ParseAmount(input: String): Double? {
    val normalized = buildString {
        input.trim().forEach { char ->
            when (char) {
                '০' -> append('0')
                '১' -> append('1')
                '২' -> append('2')
                '৩' -> append('3')
                '৪' -> append('4')
                '৫' -> append('5')
                '৬' -> append('6')
                '৭' -> append('7')
                '৮' -> append('8')
                '৯' -> append('9')
                ',', '৳', ' ' -> Unit
                else -> append(char)
            }
        }
    }
    return normalized.toDoubleOrNull()?.takeIf { it > 0.0 }
}

private fun v13Money(value: Double): String =
    if (value % 1.0 == 0.0) value.toLong().toString()
    else String.format(Locale.US, "%.2f", value)
EOF

python3 - <<'PY'
from pathlib import Path
import re

# Version bump
p = Path('app/build.gradle.kts')
s = p.read_text()
s = s.replace('versionCode = 13', 'versionCode = 14')
s = s.replace('versionName = "1.2.0"', 'versionName = "1.3.0"')
p.write_text(s)

p = Path('.github/workflows/android-build.yml')
s = p.read_text()
s = s.replace('HisabiKhata-v1.2-play-aab', 'HisabiKhata-v1.3-play-aab')
s = s.replace('HisabiKhata-v1.2-direct-apk', 'HisabiKhata-v1.3-direct-apk')
p.write_text(s)

# ViewModel patches
p = Path('app/src/main/java/com/familykhata/app/FamilyKhataViewModel.kt')
s = p.read_text()

if 'import com.familykhata.app.data.DueReceivableItem' not in s:
    s = s.replace(
        'import com.familykhata.app.data.DashboardTotals\n',
        'import com.familykhata.app.data.DashboardTotals\nimport com.familykhata.app.data.DueReceivableItem\n'
    )
if 'import kotlinx.coroutines.flow.combine' not in s:
    s = s.replace('import kotlinx.coroutines.flow.asStateFlow\n', 'import kotlinx.coroutines.flow.asStateFlow\nimport kotlinx.coroutines.flow.combine\n')

needle = '''    val bakiPeople: StateFlow<List<BakiPersonSummary>> = _selectedWorkspace
        .flatMapLatest { workspace -> dao.observeBakiSummaries(workspace) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
'''
insert = needle + '''
    private val workspacePeople = _selectedWorkspace
        .flatMapLatest { workspace -> dao.observePeople(workspace) }

    private val workspaceBakiEntries = _selectedWorkspace
        .flatMapLatest { workspace -> dao.observeWorkspaceBakiEntries(workspace) }

    val dueReceivables: StateFlow<List<DueReceivableItem>> = combine(
        workspacePeople,
        workspaceBakiEntries
    ) { people, entries ->
        calculateDueReceivables(people, entries)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
'''
if 'val dueReceivables:' not in s:
    if needle not in s:
        raise SystemExit('ViewModel: bakiPeople block not found')
    s = s.replace(needle, insert)

# write protections
s = s.replace('''    fun deleteTransaction(item: TransactionEntity) {
        viewModelScope.launch { dao.deleteTransaction(item) }
    }
''', '''    fun deleteTransaction(item: TransactionEntity) {
        if (!canWriteNow()) return
        viewModelScope.launch { dao.deleteTransaction(item) }
    }
''')
s = s.replace('''    fun deleteBakiPerson(personId: Long) {
        viewModelScope.launch { dao.deletePersonById(personId) }
    }
''', '''    fun deleteBakiPerson(personId: Long) {
        if (!canWriteNow()) return
        viewModelScope.launch { dao.deletePersonById(personId) }
    }
''')
s = s.replace('''    fun deleteBakiEntry(item: BakiEntryEntity) {
        viewModelScope.launch { dao.deleteBakiEntry(item) }
    }
''', '''    fun deleteBakiEntry(item: BakiEntryEntity) {
        if (!canWriteNow()) return
        viewModelScope.launch { dao.deleteBakiEntry(item) }
    }
''')

old_add = '''    fun addBakiEntry(personId: Long, action: String, amount: Double, note: String) {
        if (!canWriteNow() || amount <= 0) return
        val delta = when (action) {
            "GAVE" -> amount
            "RECEIVED_BACK" -> -amount
            "TOOK" -> -amount
            "PAID_BACK" -> amount
            else -> 0.0
        }
        viewModelScope.launch {
            dao.insertBakiEntry(
                BakiEntryEntity(
                    personId = personId,
                    action = action,
                    amount = amount,
                    balanceDelta = delta,
                    note = note.trim()
                )
            )
        }
    }
'''
new_add = '''    fun addBakiEntry(
        personId: Long,
        action: String,
        amount: Double,
        note: String,
        dueAt: Long? = null
    ) {
        if (!canWriteNow() || amount <= 0) return
        val delta = balanceDelta(action, amount)
        if (delta == null) return
        viewModelScope.launch {
            dao.insertBakiEntry(
                BakiEntryEntity(
                    personId = personId,
                    action = action,
                    amount = amount,
                    balanceDelta = delta,
                    note = note.trim(),
                    dueAt = dueAt
                )
            )
        }
    }

    fun updateBakiEntry(
        item: BakiEntryEntity,
        amount: Double,
        note: String,
        dueAt: Long?
    ) {
        if (!canWriteNow() || amount <= 0) return
        val delta = balanceDelta(item.action, amount) ?: return
        viewModelScope.launch {
            dao.updateBakiEntry(
                entryId = item.id,
                amount = amount,
                balanceDelta = delta,
                note = note.trim(),
                dueAt = dueAt
            )
        }
    }

    private fun balanceDelta(action: String, amount: Double): Double? = when (action) {
        "GAVE" -> amount
        "RECEIVED_BACK" -> -amount
        "TOOK" -> -amount
        "PAID_BACK" -> amount
        else -> null
    }
'''
if old_add not in s:
    raise SystemExit('ViewModel: addBakiEntry block not found')
s = s.replace(old_add, new_add)

# backup v2 + dueAt
s = s.replace('put("version", 1)', 'put("version", 2)', 1)
entry_backup = '''                                put("balanceDelta", entry.balanceDelta)
                                put("note", entry.note)
                                put("createdAt", entry.createdAt)
'''
entry_backup_new = '''                                put("balanceDelta", entry.balanceDelta)
                                put("note", entry.note)
                                if (entry.dueAt != null) put("dueAt", entry.dueAt)
                                put("createdAt", entry.createdAt)
'''
if entry_backup in s:
    s = s.replace(entry_backup, entry_backup_new, 1)

s = s.replace('''                require(root.optInt("version") == 1) {
                    "এই ব্যাকআপ ভার্সনটি এখনো সমর্থিত নয়"
                }
''', '''                val backupVersion = root.optInt("version")
                require(backupVersion in 1..2) {
                    "এই ব্যাকআপ ভার্সনটি এখনো সমর্থিত নয়"
                }
''')

restore_entry = '''                        balanceDelta = delta,
                        note = item.optString("note", ""),
                        createdAt = item.optLong("createdAt", System.currentTimeMillis())
'''
restore_entry_new = '''                        balanceDelta = delta,
                        note = item.optString("note", ""),
                        dueAt = item.optLong("dueAt", 0L).takeIf { it > 0L },
                        createdAt = item.optLong("createdAt", System.currentTimeMillis())
'''
if restore_entry not in s:
    raise SystemExit('ViewModel: restore entry block not found')
s = s.replace(restore_entry, restore_entry_new, 1)

# Add due calculation before refreshTrialStatus
marker = '    fun refreshTrialStatus() {'
if 'private fun calculateDueReceivables(' not in s:
    due_logic = '''    private data class ReceivableLot(
        val entry: BakiEntryEntity,
        var remaining: Double
    )

    private fun calculateDueReceivables(
        people: List<BakiPersonEntity>,
        entries: List<BakiEntryEntity>
    ): List<DueReceivableItem> {
        val entriesByPerson = entries.groupBy { it.personId }
        return people.flatMap { person ->
            val lots = mutableListOf<ReceivableLot>()
            entriesByPerson[person.id].orEmpty()
                .sortedWith(compareBy<BakiEntryEntity> { it.createdAt }.thenBy { it.id })
                .forEach { entry ->
                    when (entry.action) {
                        "GAVE" -> lots += ReceivableLot(entry, entry.amount)
                        "RECEIVED_BACK" -> {
                            var paymentLeft = entry.amount
                            for (lot in lots) {
                                if (paymentLeft <= 0.0) break
                                if (lot.remaining <= 0.0) continue
                                val applied = minOf(lot.remaining, paymentLeft)
                                lot.remaining -= applied
                                paymentLeft -= applied
                            }
                        }
                    }
                }
            lots.asSequence()
                .filter { it.remaining > 0.0001 && it.entry.dueAt != null }
                .map { lot ->
                    DueReceivableItem(
                        entryId = lot.entry.id,
                        personId = person.id,
                        personName = person.name,
                        phone = person.phone,
                        originalAmount = lot.entry.amount,
                        remainingAmount = lot.remaining,
                        dueAt = lot.entry.dueAt!!,
                        note = lot.entry.note
                    )
                }
                .toList()
        }.sortedWith(compareBy<DueReceivableItem> { it.dueAt }.thenBy { it.personName })
    }

'''
    if marker not in s:
        raise SystemExit('ViewModel: refresh marker not found')
    s = s.replace(marker, due_logic + marker, 1)

p.write_text(s)

# UI patches
p = Path('app/src/main/java/com/familykhata/app/ui/FamilyKhataApp.kt')
s = p.read_text()
s = s.replace('"v1.2 • Commercial Tools"', '"v1.3 • Due & Customer Tools"')
s = s.replace('Text("হিসাবী খাতা v1.2", fontWeight = FontWeight.Bold)', 'Text("হিসাবী খাতা v1.3", fontWeight = FontWeight.Bold)')

# Dashboard due summary after পাবো/দেবো metric row; insert only once
metric_block = '''        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricCard(
                title = "পাবো",
                amount = receivable,
                modifier = Modifier.weight(1f),
                accentColor = ReceivableAccent
            )
            MetricCard(
                title = "দেবো",
                amount = payable,
                modifier = Modifier.weight(1f),
                accentColor = PayableAccent
            )
        }
'''
if 'DueDashboardSection(' not in s:
    if metric_block not in s:
        raise SystemExit('UI: personal due metric block not found')
    s = s.replace(metric_block, metric_block + '''
        DueDashboardSection(
            viewModel = viewModel,
            onLedger = onLedger
        )
''', 1)

# Add due field state
state_needle = '''    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
'''
state_new = '''    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var dueAt by remember { mutableStateOf<Long?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
'''
# only in BakiEntryScreen; locate section first
idx = s.find('private fun BakiEntryScreen(')
if idx == -1:
    raise SystemExit('UI: BakiEntryScreen not found')
pre, post = s[:idx], s[idx:]
if 'var dueAt by remember' not in post[:2500]:
    if state_needle not in post:
        raise SystemExit('UI: BakiEntry state block not found')
    post = post.replace(state_needle, state_new, 1)
s = pre + post

# Insert date picker after note field inside BakiEntryScreen
note_block = '''        OutlinedTextField(
            note,
            { note = it },
            label = { Text("নোট") },
            modifier = Modifier.fillMaxWidth()
        )
'''
idx = s.find('private fun BakiEntryScreen(')
pre, post = s[:idx], s[idx:]
if 'DueDatePickerField(' not in post[:7000]:
    if note_block not in post:
        raise SystemExit('UI: BakiEntry note field not found')
    post = post.replace(note_block, note_block + '''        DueDatePickerField(
            value = dueAt,
            onChange = { dueAt = it }
        )
''', 1)
s = pre + post

# Save dueAt and reset
s = s.replace('viewModel.addBakiEntry(person.id, action, value, note)', 'viewModel.addBakiEntry(person.id, action, value, note, dueAt)', 1)
s = s.replace('''                    amount = ""
                    note = ""
                    error = null
''', '''                    amount = ""
                    note = ""
                    dueAt = null
                    error = null
''', 1)

# Replace BakiHistoryCard call
old_call = '''                BakiHistoryCard(
                    item = entry,
                    onDelete = { pendingDelete = entry }
                )
'''
new_call = '''                BakiHistoryCard(
                    item = entry,
                    person = person,
                    canWrite = canWrite,
                    viewModel = viewModel,
                    onDelete = { pendingDelete = entry }
                )
'''
if old_call not in s:
    raise SystemExit('UI: BakiHistoryCard call not found')
s = s.replace(old_call, new_call, 1)

# Replace BakiHistoryCard function
pattern = re.compile(r'@Composable\nprivate fun BakiHistoryCard\(.*?\n}\n\n@Composable\nprivate fun ActionButton', re.S)
replacement = '''@Composable
private fun BakiHistoryCard(
    item: BakiEntryEntity,
    person: BakiPersonSummary,
    canWrite: Boolean,
    viewModel: FamilyKhataViewModel,
    onDelete: () -> Unit
) {
    val accent = bakiActionAccent(item.action)
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = accent.copy(alpha = 0.08f)
        ),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.18f))
    ) {
        Column(
            modifier = Modifier.padding(13.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    actionLabel(item.action),
                    fontWeight = FontWeight.Bold,
                    color = accent
                )
                Text(
                    "৳ ${money(item.amount)}",
                    fontWeight = FontWeight.ExtraBold,
                    color = accent
                )
            }
            if (item.note.isNotBlank()) {
                Text(item.note)
            }
            item.dueAt?.let {
                Text(
                    "পরিশোধের তারিখ: ${v13Date(it)}",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold,
                    color = if (it < System.currentTimeMillis()) ExpenseAccent else ReceivableAccent
                )
            }
            Text(
                formatDate(item.createdAt),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            BakiEntryActionRow(
                person = person,
                item = item,
                canWrite = canWrite,
                viewModel = viewModel,
                onDelete = onDelete
            )
        }
    }
}

@Composable
private fun ActionButton'''
s, count = pattern.subn(replacement, s, count=1)
if count != 1:
    raise SystemExit(f'UI: BakiHistoryCard replacement count={count}')

# Purchase/tutorial section after existing commercial tools
if 'PurchaseAndTutorialSection()' not in s:
    s = s.replace('''        CommercialToolsSection(viewModel)

        MoreSectionTitle("ডেটা নিরাপত্তা")
''', '''        CommercialToolsSection(viewModel)
        PurchaseAndTutorialSection()

        MoreSectionTitle("ডেটা নিরাপত্তা")
''', 1)

p.write_text(s)

# light docs/version copy edits
for fp in [Path('docs/index.html'), Path('docs/privacy.html')]:
    if fp.exists():
        t = fp.read_text()
        t = t.replace('v1.2', 'v1.3')
        fp.write_text(t)
PY

echo "=== V1.3 SOURCE CHECK ==="
grep -q 'versionName = "1.3.0"' app/build.gradle.kts
grep -q 'version = 3' app/src/main/java/com/familykhata/app/data/AppDatabase.kt
grep -q 'val dueAt: Long?' app/src/main/java/com/familykhata/app/data/Models.kt
grep -q 'val dueReceivables:' app/src/main/java/com/familykhata/app/FamilyKhataViewModel.kt
grep -q 'DueDatePickerField' app/src/main/java/com/familykhata/app/ui/FamilyKhataApp.kt
grep -q 'PurchaseAndTutorialSection' app/src/main/java/com/familykhata/app/ui/FamilyKhataApp.kt
grep -q 'HisabiKhata-v1.3-direct-apk' .github/workflows/android-build.yml

echo "=== V1.3 DUE + CUSTOMER + COMMERCIAL PATCH APPLIED ==="
git status --short
# ==============================
# V1.4 SETTINGS + REMINDERS LAYER
# ==============================

cat > app/src/main/java/com/familykhata/app/ui/V14Settings.kt <<'EOF'
package com.familykhata.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.familykhata.app.DueReminderScheduler
import com.familykhata.app.FamilyKhataViewModel

private const val V14_PREFS = "hisabi_khata_v14_settings"
private const val SUPPORT_PHONE = "8801886665676"
private const val WEBSITE_URL_V14 = "https://uddinmezbah.github.io/Familykhata.Android_source/"
private const val TUTORIAL_URL_V14 = "https://uddinmezbah.github.io/Familykhata.Android_source/#tutorial"
private const val FEATURE_URL_V14 = "https://github.com/Uddinmezbah/Familykhata.Android_source/issues/new?title=Feature%20request%3A%20"
private const val MORE_APPS_URL_V14 = "https://github.com/Uddinmezbah"

internal object V14DisplayState {
    var currencySymbol by mutableStateOf("৳")
    var summaryVisible by mutableStateOf(true)
    private var initialized = false

    fun initialize(context: Context) {
        if (initialized) return
        val prefs = context.getSharedPreferences(V14_PREFS, Context.MODE_PRIVATE)
        currencySymbol = prefs.getString("currency_symbol", "৳") ?: "৳"
        summaryVisible = prefs.getBoolean("summary_visible", true)
        initialized = true
    }
}

@Composable
internal fun TopCornerMenuButton(onClick: () -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
        Card(
            onClick = onClick,
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.22f))
        ) {
            Text("☰  মেনু", modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp), fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
internal fun V14SettingsScreen(
    viewModel: FamilyKhataViewModel,
    onClose: () -> Unit,
    onOpenLedger: () -> Unit,
    onOpenMore: () -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences(V14_PREFS, Context.MODE_PRIVATE) }

    var profileName by remember { mutableStateOf(prefs.getString("profile_name", "") ?: "") }
    var businessName by remember { mutableStateOf(prefs.getString("business_name", "") ?: "") }
    var profilePhone by remember { mutableStateOf(prefs.getString("profile_phone", "") ?: "") }
    var showProfile by remember { mutableStateOf(false) }
    var showLanguage by remember { mutableStateOf(false) }
    var showCurrency by remember { mutableStateOf(false) }
    var showReminder by remember { mutableStateOf(false) }
    var showPlan by remember { mutableStateOf(false) }
    var showPin by remember { mutableStateOf(false) }
    var showSmsInfo by remember { mutableStateOf(false) }
    var summaryVisible by remember { mutableStateOf(prefs.getBoolean("summary_visible", true)) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onClose) { Text("✕") }
            Text("সেটিংস", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
            Text("v1.4", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }

        Card(
            onClick = { showProfile = true },
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)),
            shape = RoundedCornerShape(22.dp)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.primary) {
                    Text("👤", modifier = Modifier.padding(14.dp), style = MaterialTheme.typography.titleLarge)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(profileName.ifBlank { "আপনার প্রোফাইল" }, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                    if (businessName.isNotBlank()) Text(businessName, style = MaterialTheme.typography.bodySmall)
                    if (profilePhone.isNotBlank()) Text(profilePhone, style = MaterialTheme.typography.bodySmall)
                    if (profileName.isBlank() && profilePhone.isBlank()) Text("নাম, প্রতিষ্ঠান ও ফোন যোগ করুন", style = MaterialTheme.typography.bodySmall)
                }
                Text("›", style = MaterialTheme.typography.headlineSmall)
            }
        }

        SettingsActionCard("🌐", "ভাষা পরিবর্তন", "বাংলা সক্রিয় • English/Hindi/Arabic প্রস্তুত করা হবে") { showLanguage = true }
        SettingsActionCard("★", "প্রিমিয়াম হয়ে যান", "মাসিক • বার্ষিক • Lifetime") { showPlan = true }
        SettingsActionCard("💬", "তাগাদা মেসেজ", "SMS/WhatsApp-এ প্রস্তুত বার্তা; আলাদা SMS প্যাক এখন লাগবে না") { showSmsInfo = true }
        SettingsActionCard("🔒", "PIN / পাসওয়ার্ড পরিবর্তন", "অ্যাপ লক সেট, পরিবর্তন বা বন্ধ করুন") { showPin = true }
        SettingsActionCard("🔔", "বাকি পরিশোধের নোটিফিকেশন", "৩০/১৫/৭/৩ দিন আগে এবং নির্ধারিত দিনে মনে করাবে") { showReminder = true }
        SettingsActionCard("💱", "মুদ্রা পরিবর্তন করুন", "প্রদর্শনের মুদ্রা বদলাবে; FX conversion হবে না") { showCurrency = true }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("📄", style = MaterialTheme.typography.titleLarge)
                Column(modifier = Modifier.weight(1f)) {
                    Text("হোম সারাংশ", fontWeight = FontWeight.Bold)
                    Text(if (summaryVisible) "টাকার সারাংশ দেখা যাচ্ছে" else "টাকার সারাংশ লুকানো আছে", style = MaterialTheme.typography.bodySmall)
                }
                Switch(
                    checked = summaryVisible,
                    onCheckedChange = { checked ->
                        summaryVisible = checked
                        prefs.edit().putBoolean("summary_visible", checked).apply()
                        V14DisplayState.summaryVisible = checked
                    }
                )
            }
        }

        SettingsSectionTitle("দ্রুত কাজ")
        SettingsActionCard("👥", "কাস্টমার / ব্যক্তি খাতা", "নাম বা ফোন দিয়ে খুঁজুন, বাকি ও লেনদেন দেখুন") { onOpenLedger() }
        SettingsActionCard("↥", "ডাটা ব্যাকআপ ও রিপোর্ট", "JSON Backup/Restore এবং CSV রিপোর্ট") { onOpenMore() }
        SettingsActionCard("▶", "কিভাবে ব্যবহার করব?", "ব্যবহারের নিয়ম ও ভিডিও টিউটোরিয়াল") { openUrlV14(context, TUTORIAL_URL_V14) }
        SettingsActionCard("☏", "আমাদের সাথে যোগাযোগ করুন", "WhatsApp / SMS / Website") { openSupportChooser(context) }

        SettingsSectionTitle("শেয়ার ও তথ্য")
        SettingsActionCard("↗", "অ্যাপ শেয়ার করুন", "পরিবার, বন্ধু বা ব্যবসায়িক পরিচিতদের পাঠান") { shareAppV14(context) }
        SettingsActionCard("★", "রিভিউ দিন", "Play Store প্রকাশের পর রেটিং দিন") { openPlayStoreV14(context) }
        SettingsActionCard("▦", "আরও অ্যাপ", "ডেভেলপারের অন্যান্য প্রজেক্ট দেখুন") { openUrlV14(context, MORE_APPS_URL_V14) }
        SettingsActionCard("🌍", "ওয়েবসাইট", "হিসাবী খাতার অফিসিয়াল ওয়েব পেজ") { openUrlV14(context, WEBSITE_URL_V14) }
        SettingsActionCard("✦", "ফিচার রিকোয়েস্ট", "যে নতুন সুবিধা চান তা জানান") { openUrlV14(context, FEATURE_URL_V14) }
        SettingsActionCard("🔐", "এখনই অ্যাপ লক করুন", "PIN চালু থাকলে সঙ্গে সঙ্গে লক হবে") {
            viewModel.lockApp()
            onClose()
        }

        Text(
            "হিসাবী খাতা v1.4 • Offline-first • লোকাল ডেটা",
            modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }

    if (showProfile) {
        ProfileDialog(profileName, businessName, profilePhone, { showProfile = false }) { name, business, phone ->
            profileName = name
            businessName = business
            profilePhone = phone
            prefs.edit().putString("profile_name", name).putString("business_name", business).putString("profile_phone", phone).apply()
            showProfile = false
        }
    }
    if (showLanguage) LanguageDialog { showLanguage = false }
    if (showCurrency) CurrencyDialog(
        currentCode = prefs.getString("currency_code", "BDT") ?: "BDT",
        onDismiss = { showCurrency = false },
        onSelect = { code, symbol ->
            prefs.edit().putString("currency_code", code).putString("currency_symbol", symbol).apply()
            V14DisplayState.currencySymbol = symbol
            showCurrency = false
        }
    )
    if (showReminder) ReminderSettingsDialog(context, prefs) { showReminder = false }
    if (showPlan) PlanPurchaseDialog(context) { showPlan = false }
    if (showPin) PinSettingsDialog(viewModel) { showPin = false }
    if (showSmsInfo) {
        AlertDialog(
            onDismissRequest = { showSmsInfo = false },
            title = { Text("তাগাদা মেসেজ") },
            text = { Text("প্রতিটি বাকি এন্ট্রির নিচে SMS, WhatsApp ও Call থাকবে। SMS/WhatsApp আপনার ফোনের অ্যাপ খুলে প্রস্তুত বার্তা দেবে। তাই v1.4-এ আলাদা SMS credit কেনার প্রয়োজন নেই।") },
            confirmButton = { TextButton(onClick = { showSmsInfo = false }) { Text("ঠিক আছে") } }
        )
    }
}

@Composable
private fun SettingsActionCard(symbol: String, title: String, subtitle: String, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.48f)),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.14f))
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(symbol, style = MaterialTheme.typography.titleLarge)
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("›", style = MaterialTheme.typography.titleLarge)
        }
    }
}

@Composable
private fun SettingsSectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 4.dp))
}

@Composable
private fun ProfileDialog(
    initialName: String,
    initialBusiness: String,
    initialPhone: String,
    onDismiss: () -> Unit,
    onSave: (String, String, String) -> Unit
) {
    var name by remember { mutableStateOf(initialName) }
    var business by remember { mutableStateOf(initialBusiness) }
    var phone by remember { mutableStateOf(initialPhone) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("প্রোফাইল") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("নাম") }, singleLine = true)
                OutlinedTextField(business, { business = it }, label = { Text("প্রতিষ্ঠান (ঐচ্ছিক)") }, singleLine = true)
                OutlinedTextField(phone, { phone = it }, label = { Text("ফোন") }, singleLine = true)
            }
        },
        confirmButton = { TextButton(onClick = { onSave(name.trim(), business.trim(), phone.trim()) }) { Text("সেভ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@Composable
private fun LanguageDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Select app language") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("বাংলা ✓") }
                OutlinedButton(onClick = {}, enabled = false, modifier = Modifier.fillMaxWidth()) { Text("English — শিগগিরই") }
                OutlinedButton(onClick = {}, enabled = false, modifier = Modifier.fillMaxWidth()) { Text("हिंदी — শিগগিরই") }
                OutlinedButton(onClick = {}, enabled = false, modifier = Modifier.fillMaxWidth()) { Text("العربية — শিগগিরই") }
                Text("v1.4-এ বাংলা সম্পূর্ণ সক্রিয়। অন্য ভাষাগুলো পুরো UI translation resource-এ স্থানান্তরের পর চালু করা হবে।", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("সম্পন্ন") } }
    )
}

private data class CurrencyChoice(val country: String, val code: String, val symbol: String)

@Composable
private fun CurrencyDialog(currentCode: String, onDismiss: () -> Unit, onSelect: (String, String) -> Unit) {
    val choices = listOf(
        CurrencyChoice("বাংলাদেশ", "BDT", "৳"),
        CurrencyChoice("ভারত", "INR", "₹"),
        CurrencyChoice("পাকিস্তান", "PKR", "Rs"),
        CurrencyChoice("শ্রীলঙ্কা", "LKR", "Rs"),
        CurrencyChoice("নেপাল", "NPR", "रू"),
        CurrencyChoice("সংযুক্ত আরব আমিরাত", "AED", "د.إ"),
        CurrencyChoice("সৌদি আরব", "SAR", "ر.س"),
        CurrencyChoice("কাতার", "QAR", "ر.ق"),
        CurrencyChoice("কুয়েত", "KWD", "د.ك"),
        CurrencyChoice("ইরাক", "IQD", "ع.د")
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("মুদ্রা নির্বাচন করুন") },
        text = {
            Column(modifier = Modifier.heightIn(max = 470.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                choices.forEach { item ->
                    if (item.code == currentCode) {
                        Button(onClick = { onSelect(item.code, item.symbol) }, modifier = Modifier.fillMaxWidth()) { Text("${item.country} — ${item.code}  ${item.symbol}") }
                    } else {
                        OutlinedButton(onClick = { onSelect(item.code, item.symbol) }, modifier = Modifier.fillMaxWidth()) { Text("${item.country} — ${item.code}  ${item.symbol}") }
                    }
                }
                Text("এটি শুধু display symbol/unit বদলায়; টাকার মান convert করে না।", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@Composable
private fun ReminderSettingsDialog(context: Context, prefs: android.content.SharedPreferences, onDismiss: () -> Unit) {
    var d30 by remember { mutableStateOf(prefs.getBoolean("reminder_30", false)) }
    var d15 by remember { mutableStateOf(prefs.getBoolean("reminder_15", false)) }
    var d7 by remember { mutableStateOf(prefs.getBoolean("reminder_7", true)) }
    var d3 by remember { mutableStateOf(prefs.getBoolean("reminder_3", true)) }
    var d0 by remember { mutableStateOf(prefs.getBoolean("reminder_0", true)) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        Toast.makeText(context, if (granted) "নোটিফিকেশন অনুমতি দেওয়া হয়েছে" else "নোটিফিকেশন অনুমতি দেওয়া হয়নি", Toast.LENGTH_SHORT).show()
    }

    fun save() {
        prefs.edit().putBoolean("reminder_30", d30).putBoolean("reminder_15", d15).putBoolean("reminder_7", d7).putBoolean("reminder_3", d3).putBoolean("reminder_0", d0).apply()
        DueReminderScheduler.schedule(context)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("বাকি পরিশোধের নোটিফিকেশন") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ReminderSwitch("৩০ দিন আগে", d30) { d30 = it }
                ReminderSwitch("১৫ দিন আগে", d15) { d15 = it }
                ReminderSwitch("৭ দিন আগে", d7) { d7 = it }
                ReminderSwitch("৩ দিন আগে", d3) { d3 = it }
                ReminderSwitch("নির্ধারিত দিনে", d0) { d0 = it }
                if (Build.VERSION.SDK_INT >= 33) {
                    OutlinedButton(onClick = { permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }, modifier = Modifier.fillMaxWidth()) { Text("নোটিফিকেশন অনুমতি দিন") }
                }
                Text("রিমাইন্ডার লোকাল ডাটাবেস দেখে কাজ করবে; ইন্টারনেট প্রয়োজন নেই।", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(onClick = { save(); onDismiss() }) { Text("সেভ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@Composable
private fun ReminderSwitch(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun PlanPurchaseDialog(context: Context, onDismiss: () -> Unit) {
    var plan by remember { mutableStateOf("মাসিক") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("প্রিমিয়াম প্ল্যান") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("মাসিক", "বার্ষিক", "Lifetime").forEach { item ->
                    if (plan == item) Button(onClick = { plan = item }, modifier = Modifier.fillMaxWidth()) { Text(item) }
                    else OutlinedButton(onClick = { plan = item }, modifier = Modifier.fillMaxWidth()) { Text(item) }
                }
                Text("৩০ দিনের trial শেষে পুরনো ডেটা থাকবে; নতুন Add/Edit সীমিত হবে। $plan প্ল্যানের দাম ও activation পেতে যোগাযোগ করুন।", style = MaterialTheme.typography.bodySmall)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { purchaseWhatsAppV14(context, plan) }, modifier = Modifier.weight(1f)) { Text("WhatsApp") }
                    OutlinedButton(onClick = { purchaseSmsV14(context, plan) }, modifier = Modifier.weight(1f)) { Text("SMS") }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { purchaseMessengerV14(context, plan) }, modifier = Modifier.weight(1f)) { Text("Messenger") }
                    OutlinedButton(onClick = { openUrlV14(context, WEBSITE_URL_V14) }, modifier = Modifier.weight(1f)) { Text("Website") }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("বন্ধ") } }
    )
}

@Composable
private fun PinSettingsDialog(viewModel: FamilyKhataViewModel, onDismiss: () -> Unit) {
    val configured = viewModel.isPinConfigured.value
    var current by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (configured) "PIN পরিবর্তন" else "PIN সেট করুন") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (configured) OutlinedTextField(current, { current = it.filter(Char::isDigit).take(6) }, label = { Text("বর্তমান PIN") }, visualTransformation = PasswordVisualTransformation())
                OutlinedTextField(pin, { pin = it.filter(Char::isDigit).take(6) }, label = { Text("নতুন PIN") }, visualTransformation = PasswordVisualTransformation())
                OutlinedTextField(confirm, { confirm = it.filter(Char::isDigit).take(6) }, label = { Text("নতুন PIN আবার") }, visualTransformation = PasswordVisualTransformation())
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                if (configured) {
                    OutlinedButton(
                        onClick = { if (viewModel.disablePin(current)) onDismiss() else error = "বর্তমান PIN সঠিক নয়" },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("PIN বন্ধ করুন") }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                error = when {
                    pin.length !in 4..6 -> "PIN ৪–৬ সংখ্যার হতে হবে"
                    pin != confirm -> "দুইটি PIN মিলছে না"
                    configured && !viewModel.changePin(current, pin) -> "বর্তমান PIN সঠিক নয়"
                    !configured && !viewModel.setPin(pin) -> "PIN সেট করা যায়নি"
                    else -> { onDismiss(); null }
                }
            }) { Text("সেভ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

private fun purchaseMessageV14(plan: String) = "আমি হিসাবী খাতা অ্যাপের $plan প্ল্যান নিতে চাই। পেমেন্ট ও activation নির্দেশনা দিন।"

private fun purchaseWhatsAppV14(context: Context, plan: String) {
    openUrlV14(context, "https://wa.me/$SUPPORT_PHONE?text=${Uri.encode(purchaseMessageV14(plan))}")
}

private fun purchaseSmsV14(context: Context, plan: String) {
    runCatching {
        context.startActivity(Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:$SUPPORT_PHONE")
            putExtra("sms_body", purchaseMessageV14(plan))
        })
    }
}

private fun purchaseMessengerV14(context: Context, plan: String) {
    val message = purchaseMessageV14(plan)
    runCatching {
        context.startActivity(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, message)
            setPackage("com.facebook.orca")
        })
    }.recoverCatching {
        context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, message)
        }, "যোগাযোগ করুন"))
    }
}

private fun openSupportChooser(context: Context) {
    runCatching {
        context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "হিসাবী খাতা সাপোর্ট প্রয়োজন।")
        }, "যোগাযোগের মাধ্যম বেছে নিন"))
    }
}

private fun shareAppV14(context: Context) {
    runCatching {
        context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "হিসাবী খাতা – আয়, খরচ ও বাকি হিসাব\n$WEBSITE_URL_V14")
        }, "অ্যাপ শেয়ার করুন"))
    }
}

private fun openPlayStoreV14(context: Context) {
    val pkg = "com.familykhata.app"
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg"))) }
        .recoverCatching { openUrlV14(context, "https://play.google.com/store/apps/details?id=$pkg") }
}

private fun openUrlV14(context: Context, url: String) {
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        .onFailure { Toast.makeText(context, "লিংক খোলা যায়নি", Toast.LENGTH_SHORT).show() }
}
EOF

cat > app/src/main/java/com/familykhata/app/DueReminderWorker.kt <<'EOF'
package com.familykhata.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.familykhata.app.data.AppDatabase
import com.familykhata.app.data.BakiEntryEntity
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.TimeUnit

private const val REMINDER_WORK = "hisabi-khata-due-reminders"
private const val CHANNEL_ID = "due_reminders"
private const val V14_PREFS_WORKER = "hisabi_khata_v14_settings"
private const val DAY_MS_WORKER = 86_400_000L

object DueReminderScheduler {
    fun schedule(context: Context) {
        val request = PeriodicWorkRequestBuilder<DueReminderWorker>(24, TimeUnit.HOURS).build()
        WorkManager.getInstance(context.applicationContext).enqueueUniquePeriodicWork(
            REMINDER_WORK,
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }
}

class DueReminderWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    private data class Lot(val entry: BakiEntryEntity, var remaining: Double)

    override suspend fun doWork(): Result {
        if (Build.VERSION.SDK_INT >= 33 && applicationContext.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return Result.success()
        }
        val prefs = applicationContext.getSharedPreferences(V14_PREFS_WORKER, Context.MODE_PRIVATE)
        val enabled = buildSet {
            if (prefs.getBoolean("reminder_30", false)) add(30)
            if (prefs.getBoolean("reminder_15", false)) add(15)
            if (prefs.getBoolean("reminder_7", true)) add(7)
            if (prefs.getBoolean("reminder_3", true)) add(3)
            if (prefs.getBoolean("reminder_0", true)) add(0)
        }
        if (enabled.isEmpty()) return Result.success()

        createChannel()
        val dao = AppDatabase.get(applicationContext).dao()
        val people = dao.getAllPeople()
        val entries = dao.getAllBakiEntries().groupBy { it.personId }
        val today = startOfDay(System.currentTimeMillis())
        val symbol = prefs.getString("currency_symbol", "৳") ?: "৳"

        people.forEach { person ->
            val lots = mutableListOf<Lot>()
            entries[person.id].orEmpty().sortedWith(compareBy<BakiEntryEntity> { it.createdAt }.thenBy { it.id }).forEach { entry ->
                when (entry.action) {
                    "GAVE" -> lots += Lot(entry, entry.amount)
                    "RECEIVED_BACK" -> {
                        var left = entry.amount
                        for (lot in lots) {
                            if (left <= 0.0) break
                            if (lot.remaining <= 0.0) continue
                            val used = minOf(left, lot.remaining)
                            lot.remaining -= used
                            left -= used
                        }
                    }
                }
            }
            lots.filter { it.remaining > 0.0001 && it.entry.dueAt != null }.forEach { lot ->
                val days = ((startOfDay(lot.entry.dueAt!!) - today) / DAY_MS_WORKER).toInt()
                if (days !in enabled) return@forEach
                val whenText = when (days) {
                    0 -> "আজ পরিশোধের তারিখ"
                    3 -> "৩ দিন পর পরিশোধের তারিখ"
                    7 -> "৭ দিন পর পরিশোধের তারিখ"
                    15 -> "১৫ দিন পর পরিশোধের তারিখ"
                    30 -> "৩০ দিন পর পরিশোধের তারিখ"
                    else -> "$days দিন পর পরিশোধের তারিখ"
                }
                val amount = if (lot.remaining % 1.0 == 0.0) lot.remaining.toLong().toString() else String.format(Locale.US, "%.2f", lot.remaining)
                val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle("${person.name} • $whenText")
                    .setContentText("পাওনা $symbol $amount")
                    .setStyle(NotificationCompat.BigTextStyle().bigText("${person.name}-এর কাছে পাওনা $symbol $amount। $whenText।"))
                    .setAutoCancel(true)
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .build()
                val id = ((lot.entry.id % 100000L).toInt() * 37 + days + 31).coerceAtLeast(1)
                NotificationManagerCompat.from(applicationContext).notify(id, notification)
            }
        }
        return Result.success()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            applicationContext.getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "বাকি পরিশোধের রিমাইন্ডার", NotificationManager.IMPORTANCE_DEFAULT).apply {
                    description = "বাকি/পাওনার নির্ধারিত তারিখের আগে লোকাল রিমাইন্ডার"
                }
            )
        }
    }

    private fun startOfDay(value: Long): Long = Calendar.getInstance().apply {
        timeInMillis = value
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis
}
EOF

python3 - <<'PY'
from pathlib import Path

p = Path('app/build.gradle.kts')
s = p.read_text().replace('versionCode = 14', 'versionCode = 15').replace('versionName = "1.3.0"', 'versionName = "1.4.0"')
if 'androidx.work:work-runtime-ktx' not in s:
    s = s.replace('implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")', 'implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")\n    implementation("androidx.work:work-runtime-ktx:2.9.1")')
p.write_text(s)

p = Path('.github/workflows/android-build.yml')
s = p.read_text().replace('HisabiKhata-v1.3-play-aab', 'HisabiKhata-v1.4-play-aab').replace('HisabiKhata-v1.3-direct-apk', 'HisabiKhata-v1.4-direct-apk')
p.write_text(s)

p = Path('app/src/main/AndroidManifest.xml')
s = p.read_text()
if 'POST_NOTIFICATIONS' not in s:
    s = s.replace('<manifest xmlns:android="http://schemas.android.com/apk/res/android">\n', '<manifest xmlns:android="http://schemas.android.com/apk/res/android">\n    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />\n')
p.write_text(s)

p = Path('app/src/main/java/com/familykhata/app/MainActivity.kt')
s = p.read_text()
if 'DueReminderScheduler.schedule' not in s:
    s = s.replace('super.onCreate(savedInstanceState)\n', 'super.onCreate(savedInstanceState)\n        DueReminderScheduler.schedule(applicationContext)\n')
p.write_text(s)

p = Path('app/src/main/java/com/familykhata/app/ui/FamilyKhataApp.kt')
s = p.read_text()
if 'import androidx.compose.runtime.LaunchedEffect' not in s:
    s = s.replace('import androidx.compose.runtime.Composable\n', 'import androidx.compose.runtime.Composable\nimport androidx.compose.runtime.LaunchedEffect\n')
anchor = '    val isAppUnlocked by viewModel.isAppUnlocked.collectAsState()\n'
if 'showSettingsMenu' not in s:
    s = s.replace(anchor, anchor + '    val appContext = LocalContext.current\n    var showSettingsMenu by remember { mutableStateOf(false) }\n    LaunchedEffect(Unit) { V14DisplayState.initialize(appContext) }\n')
old = '''        if (!isAppUnlocked) {
            AppLockScreen(viewModel)
        } else {
            Scaffold('''
new = '''        if (!isAppUnlocked) {
            AppLockScreen(viewModel)
        } else if (showSettingsMenu) {
            V14SettingsScreen(
                viewModel = viewModel,
                onClose = { showSettingsMenu = false },
                onOpenLedger = { showSettingsMenu = false; tab = Tab.BAKI },
                onOpenMore = { showSettingsMenu = false; tab = Tab.MORE }
            )
        } else {
            Scaffold('''
if old not in s:
    raise SystemExit('FamilyKhataApp route anchor not found')
s = s.replace(old, new, 1)
if 'TopCornerMenuButton' not in s:
    s = s.replace('''                BrandHeader(workspace)
                Spacer(Modifier.height(10.dp))
''', '''                TopCornerMenuButton { showSettingsMenu = true }
                Spacer(Modifier.height(6.dp))
                BrandHeader(workspace)
                Spacer(Modifier.height(10.dp))
''', 1)
s = s.replace('"v1.3 • Due & Customer Tools"', '"v1.4 • Smart Due & Settings"')
s = s.replace('Text("হিসাবী খাতা v1.3", fontWeight = FontWeight.Bold)', 'Text("হিসাবী খাতা v1.4", fontWeight = FontWeight.Bold)')

# Selected currency replaces hard-coded BDT sign in app UI/messages.
s = s.replace('৳ ${money(', '${V14DisplayState.currencySymbol} ${money(')
# Dashboard totals privacy: mask dashboard cards while leaving ledger rows intact.
s = s.replace('''                    "${V14DisplayState.currencySymbol} ${money(balance)}",
                    style = MaterialTheme.typography.headlineLarge,''', '''                    if (V14DisplayState.summaryVisible) "${V14DisplayState.currencySymbol} ${money(balance)}" else "••••",
                    style = MaterialTheme.typography.headlineLarge,''', 1)
idx = s.find('private fun BusinessDashboard(')
if idx != -1:
    pre, post = s[:idx], s[idx:]
    post = post.replace('''                    "${V14DisplayState.currencySymbol} ${money(balance)}",
                    style = MaterialTheme.typography.headlineLarge,''', '''                    if (V14DisplayState.summaryVisible) "${V14DisplayState.currencySymbol} ${money(balance)}" else "••••",
                    style = MaterialTheme.typography.headlineLarge,''', 1)
    s = pre + post
s = s.replace('''            Text(
                "${V14DisplayState.currencySymbol} ${money(amount)}",
                style = MaterialTheme.typography.titleLarge,''', '''            Text(
                if (V14DisplayState.summaryVisible) "${V14DisplayState.currencySymbol} ${money(amount)}" else "••••",
                style = MaterialTheme.typography.titleLarge,''', 1)

call_anchor = '''        BusinessDashboard(
            balance = balance,'''
if call_anchor in s:
    s = s.replace(call_anchor, '''        BusinessDashboard(
            viewModel = viewModel,
            balance = balance,''', 1)
sig_anchor = '''private fun BusinessDashboard(
    balance: Double,'''
if sig_anchor in s:
    s = s.replace(sig_anchor, '''private fun BusinessDashboard(
    viewModel: FamilyKhataViewModel,
    balance: Double,''', 1)
idx = s.find('private fun BusinessDashboard(')
if idx != -1:
    pre, post = s[:idx], s[idx:]
    target = '''        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricCard(
                title = "পাবো",
                amount = receivable,
                modifier = Modifier.weight(1f),
                accentColor = ReceivableAccent
            )
            MetricCard(
                title = "দেবো",
                amount = payable,
                modifier = Modifier.weight(1f),
                accentColor = PayableAccent
            )
        }
'''
    if target in post and 'DueDashboardSection(\n            viewModel = viewModel' not in post[:8000]:
        post = post.replace(target, target + '''
        DueDashboardSection(
            viewModel = viewModel,
            onLedger = onLedger
        )
''', 1)
    s = pre + post
p.write_text(s)

p = Path('app/src/main/java/com/familykhata/app/ui/V13Features.kt')
s = p.read_text()
s = s.replace('"৳ ${v13Money(amount)}"', 'if (V14DisplayState.summaryVisible) "${V14DisplayState.currencySymbol} ${v13Money(amount)}" else "••••"')
s = s.replace('হিসাবী খাতা অনুযায়ী ৳ ${v13Money(item.amount)}', 'হিসাবী খাতা অনুযায়ী ${V14DisplayState.currencySymbol} ${v13Money(item.amount)}')
oldrow = '''        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            OutlinedButton(
                onClick = { sendEntrySms(context, person, item) },
                enabled = person.phone.isNotBlank(),
                modifier = Modifier.weight(1f)
            ) { Text("SMS") }
            OutlinedButton(
                onClick = { callPerson(context, person.phone) },
                enabled = person.phone.isNotBlank(),
                modifier = Modifier.weight(1f)
            ) { Text("Call") }
        }
'''
newrow = '''        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            OutlinedButton(
                onClick = { sendEntrySms(context, person, item) },
                enabled = person.phone.isNotBlank(),
                modifier = Modifier.weight(1f)
            ) { Text("SMS") }
            OutlinedButton(
                onClick = { sendEntryWhatsApp(context, person, item) },
                enabled = person.phone.isNotBlank(),
                modifier = Modifier.weight(1f)
            ) { Text("WhatsApp") }
            OutlinedButton(
                onClick = { callPerson(context, person.phone) },
                enabled = person.phone.isNotBlank(),
                modifier = Modifier.weight(1f)
            ) { Text("Call") }
        }
'''
if oldrow in s:
    s = s.replace(oldrow, newrow, 1)
if 'private fun sendEntryWhatsApp' not in s:
    marker = 'private fun callPerson(context: Context, phone: String) {'
    helper = '''private fun sendEntryWhatsApp(context: Context, person: BakiPersonSummary, item: BakiEntryEntity) {
    val dueText = item.dueAt?.let { " পরিশোধের তারিখ ${v13Date(it)}।" }.orEmpty()
    val message = "আসসালামু আলাইকুম ${person.name}, হিসাবী খাতা অনুযায়ী ${V14DisplayState.currencySymbol} ${v13Money(item.amount)} টাকার একটি হিসাব আছে.$dueText সুবিধামতো পরিশোধ/যোগাযোগ করার অনুরোধ রইল।"
    val phone = person.phone.filter(Char::isDigit).let { digits -> if (digits.startsWith("0")) "88$digits" else digits }
    v13OpenUrl(context, "https://wa.me/$phone?text=${Uri.encode(message)}")
}

'''
    s = s.replace(marker, helper + marker, 1)
p.write_text(s)

p = Path('app/src/main/java/com/familykhata/app/ui/CommercialFeatures.kt')
s = p.read_text().replace('৳ ${commercialMoney(', '${V14DisplayState.currencySymbol} ${commercialMoney(')
p.write_text(s)

p = Path('docs/index.html')
if p.exists():
    s = p.read_text().replace('v1.3', 'v1.4').replace('v1.2', 'v1.4')
    if 'id="tutorial"' not in s:
        insert = '''
    <section id="tutorial">
      <div class="panel">
        <h2>কিভাবে ব্যবহার করবেন?</h2>
        <p>১) নিজের/পরিবার/দোকান খাতা বেছে নিন। ২) ব্যক্তি/কাস্টমারের নাম ও ফোন যোগ করুন। ৩) বাকি এন্ট্রিতে পরিশোধের তারিখ দিন। ৪) “আজকে পাবো” ও reminder দেখে ফলোআপ করুন। ৫) নিয়মিত JSON backup রাখুন।</p>
        <p><strong>ভিডিও টিউটোরিয়াল:</strong> অফিসিয়াল ভিডিও প্রকাশ হলে এই অংশেই embed/link দেওয়া হবে।</p>
      </div>
    </section>
'''
        s = s.replace('  </main>', insert + '\n  </main>')
    p.write_text(s)

p = Path('docs/privacy.html')
if p.exists(): p.write_text(p.read_text().replace('v1.3', 'v1.4').replace('v1.2', 'v1.4'))
PY

echo "=== V1.4 COMPLETE CHECK ==="
grep -q 'versionName = "1.4.0"' app/build.gradle.kts
grep -q 'work-runtime-ktx:2.9.1' app/build.gradle.kts
grep -q 'HisabiKhata-v1.4-direct-apk' .github/workflows/android-build.yml
grep -q 'POST_NOTIFICATIONS' app/src/main/AndroidManifest.xml
grep -q 'DueReminderScheduler.schedule' app/src/main/java/com/familykhata/app/MainActivity.kt
grep -q 'V14SettingsScreen' app/src/main/java/com/familykhata/app/ui/FamilyKhataApp.kt
grep -q 'TopCornerMenuButton' app/src/main/java/com/familykhata/app/ui/FamilyKhataApp.kt
grep -q 'WhatsApp' app/src/main/java/com/familykhata/app/ui/V13Features.kt
grep -q 'class DueReminderWorker' app/src/main/java/com/familykhata/app/DueReminderWorker.kt
grep -q 'id="tutorial"' docs/index.html

echo "=== HISABI KHATA V1.4 COMBINED UPGRADE APPLIED ==="
echo "Base expected: stable v1.2 main. v1.3 does NOT need to be pushed first."
git status --short
