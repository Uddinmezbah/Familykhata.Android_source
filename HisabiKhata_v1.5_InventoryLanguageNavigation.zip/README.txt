Hisabi Khata v1.5 test patch
Base: stable v1.4 main branch

Adds:
- First-launch Bangla / English language chooser
- Customer/person list-first UX and Android Back navigation
- Product + stock module with batch purchase dates and expiry dates
- Barcode/SKU input and Google Code Scanner button
- Low-stock / out-of-stock / expiry notifications
- Product stock add/reduce, edit/delete
- Inventory included in JSON backup/restore version 3
- v1.5-test GitHub Actions branch support and v1.5 artifact names

Apply only on a v1.5-test branch. Do not merge to main until GitHub Actions succeeds and the APK is tested.
