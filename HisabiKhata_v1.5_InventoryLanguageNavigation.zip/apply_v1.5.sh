#!/usr/bin/env bash
set -euo pipefail

ROOT="$(pwd)"
[ -f "$ROOT/app/build.gradle.kts" ] || { echo "Run this from the repository root"; exit 1; }
[ -d "$ROOT/v15_payload" ] || { echo "v15_payload folder not found"; exit 1; }

python3 - <<'PY'
from pathlib import Path

root = Path.cwd()

def read(rel):
    p = root / rel
    if not p.exists():
        raise SystemExit(f"Missing required file: {rel}")
    return p.read_text()

def write(rel, text):
    (root / rel).write_text(text)

def must_replace(text, old, new, label, count=1):
    n = text.count(old)
    if n < count:
        raise SystemExit(f"Patch anchor not found for {label}: expected >= {count}, got {n}")
    return text.replace(old, new, count)

# --- Gradle/version ---
p = "app/build.gradle.kts"
t = read(p)
t = must_replace(t, 'versionCode = 15', 'versionCode = 16', 'versionCode')
t = must_replace(t, 'versionName = "1.4.0"', 'versionName = "1.5.0"', 'versionName')
if 'play-services-code-scanner' not in t:
    t = must_replace(
        t,
        '    implementation("androidx.work:work-runtime-ktx:2.9.1")\n',
        '    implementation("androidx.work:work-runtime-ktx:2.9.1")\n    implementation("com.google.android.gms:play-services-code-scanner:16.1.0")\n',
        'barcode scanner dependency'
    )
write(p, t)

# --- GitHub Actions v1.5 test + artifacts ---
p = ".github/workflows/android-build.yml"
t = read(p)
if '"v1.5-test"' not in t:
    if 'branches: [ "main", "v1.4-test" ]' in t:
        t = t.replace('branches: [ "main", "v1.4-test" ]', 'branches: [ "main", "v1.4-test", "v1.5-test" ]', 1)
    elif 'branches: [ "main" ]' in t:
        t = t.replace('branches: [ "main" ]', 'branches: [ "main", "v1.5-test" ]', 1)
    else:
        raise SystemExit('Workflow branch anchor not found')
t = t.replace('HisabiKhata-v1.4-play-aab', 'HisabiKhata-v1.5-play-aab')
t = t.replace('HisabiKhata-v1.4-direct-apk', 'HisabiKhata-v1.5-direct-apk')
write(p, t)

# --- MainActivity inventory reminders ---
p = "app/src/main/java/com/familykhata/app/MainActivity.kt"
t = read(p)
if 'InventoryReminderScheduler.schedule' not in t:
    t = must_replace(
        t,
        '        DueReminderScheduler.schedule(applicationContext)\n',
        '        DueReminderScheduler.schedule(applicationContext)\n        InventoryReminderScheduler.schedule(applicationContext)\n',
        'inventory scheduler'
    )
write(p, t)

# --- FamilyKhataApp shell/navigation/customer UX ---
p = "app/src/main/java/com/familykhata/app/ui/FamilyKhataApp.kt"
t = read(p)
if 'import androidx.activity.compose.BackHandler' not in t:
    t = must_replace(t, 'import android.widget.Toast\n', 'import android.widget.Toast\nimport androidx.activity.compose.BackHandler\n', 'BackHandler import')

t = must_replace(
    t,
    '    BAKI("বাকি"),\n    HISTORY("হিসাব"),',
    '    BAKI("বাকি"),\n    PRODUCTS("পণ্য"),\n    HISTORY("হিসাব"),',
    'PRODUCTS tab'
)

t = must_replace(
    t,
    '    val appContext = LocalContext.current\n    var showSettingsMenu by remember { mutableStateOf(false) }\n    LaunchedEffect(Unit) { V14DisplayState.initialize(appContext) }',
    '    val appContext = LocalContext.current\n    V15LanguageState.ensureInitialized(appContext)\n    var showSettingsMenu by remember { mutableStateOf(false) }\n    LaunchedEffect(Unit) { V14DisplayState.initialize(appContext) }',
    'language initialization'
)

t = must_replace(
    t,
    '    HisabiKhataTheme {\n        if (!isAppUnlocked) {',
    '    HisabiKhataTheme {\n        if (V15LanguageState.languageCode == null) {\n            LanguageOnboardingScreen()\n        } else if (!isAppUnlocked) {',
    'language gate'
)

t = must_replace(
    t,
    '                onOpenLedger = { showSettingsMenu = false; tab = Tab.BAKI },\n                onOpenMore = { showSettingsMenu = false; tab = Tab.MORE }',
    '                onOpenLedger = { showSettingsMenu = false; tab = Tab.BAKI },\n                onOpenProducts = { showSettingsMenu = false; tab = Tab.PRODUCTS },\n                onOpenMore = { showSettingsMenu = false; tab = Tab.MORE }',
    'settings product navigation'
)

t = must_replace(
    t,
    '                    Tab.entries.forEach { item ->',
    '                    val navTabs = if (workspace == "SHOP") {\n                        listOf(Tab.DASHBOARD, Tab.ADD, Tab.BAKI, Tab.PRODUCTS, Tab.HISTORY)\n                    } else {\n                        listOf(Tab.DASHBOARD, Tab.ADD, Tab.BAKI, Tab.HISTORY, Tab.MORE)\n                    }\n                    navTabs.forEach { item ->',
    'dynamic bottom tabs'
)

t = must_replace(
    t,
    '                        Tab.BAKI -> BakiScreen(viewModel, workspace, canWrite = !trialStatus.expired)\n                        Tab.HISTORY -> HistoryScreen(viewModel, workspace)',
    '                        Tab.BAKI -> BakiScreen(\n                            viewModel = viewModel,\n                            workspace = workspace,\n                            canWrite = !trialStatus.expired,\n                            onExit = { tab = Tab.DASHBOARD }\n                        )\n                        Tab.PRODUCTS -> V15InventoryScreen(\n                            workspace = workspace,\n                            canWrite = !trialStatus.expired,\n                            onExit = { tab = Tab.DASHBOARD }\n                        )\n                        Tab.HISTORY -> HistoryScreen(viewModel, workspace)',
    'product/customer screens'
)

t = t.replace('"v1.4 • Smart Due & Settings"', '"v1.5 • Customers, Stock & Expiry"')

# Replace BakiScreen with phone-back aware page navigation.
start = t.index('@Composable\nprivate fun BakiScreen(')
end = t.index('@Composable\nprivate fun BakiPeopleScreen(', start)
new_baki_screen = '''@Composable
private fun BakiScreen(
    viewModel: FamilyKhataViewModel,
    workspace: String,
    canWrite: Boolean,
    onExit: () -> Unit
) {
    val people by viewModel.bakiPeople.collectAsState()
    var selectedId by remember { mutableStateOf<Long?>(null) }
    val selected = selectedId?.let { id -> people.firstOrNull { it.id == id } }

    BackHandler(enabled = selected != null) { selectedId = null }
    BackHandler(enabled = selected == null) { onExit() }

    if (selected == null) {
        BakiPeopleScreen(
            people = people,
            viewModel = viewModel,
            workspace = workspace,
            canWrite = canWrite,
            onSelect = { selectedId = it.id }
        )
    } else {
        BakiEntryScreen(
            person = selected,
            viewModel = viewModel,
            workspace = workspace,
            canWrite = canWrite,
            onBack = { selectedId = null }
        )
    }
}

'''
t = t[:start] + new_baki_screen + t[end:]

# Replace customer/person list: names first, add via dialog instead of a long form above the list.
start = t.index('@Composable\nprivate fun BakiPeopleScreen(')
end = t.index('@Composable\nprivate fun BakiEntryScreen(', start)
new_people = '''@Composable
private fun BakiPeopleScreen(
    people: List<BakiPersonSummary>,
    viewModel: FamilyKhataViewModel,
    workspace: String,
    canWrite: Boolean,
    onSelect: (BakiPersonSummary) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }
    val personLabel = if (workspace == "SHOP") v15Text("কাস্টমার/সাপ্লায়ার", "Customer/Supplier") else v15Text("ব্যক্তি", "Person")
    val sectionTitle = if (workspace == "SHOP") v15Text("কাস্টমার/সাপ্লায়ার", "Customers & Suppliers") else v15Text("বাকি/পাওনা", "Due Accounts")
    val dueItems by viewModel.dueReceivables.collectAsState()

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(sectionTitle, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
        Text(
            v15Text("নামগুলো সামনে থাকবে। যেকোনো নাম চাপলে আলাদা খাতা খুলবে; ফোনের Back দিলে আবার এই তালিকায় ফিরবেন।", "Names stay on this list. Tap a name to open its ledger; use the phone Back button to return here."),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Button(onClick = { showAdd = true }, enabled = canWrite, modifier = Modifier.fillMaxWidth()) {
            Text(v15Text("＋ নতুন $personLabel যোগ করুন", "＋ Add $personLabel"))
        }
        if (!canWrite) TrialLockedMessage()

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text(v15Text("নাম বা ফোন দিয়ে খুঁজুন", "Search by name or phone")) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        val filteredPeople = people.filter { person ->
            query.isBlank() || person.name.contains(query, ignoreCase = true) || person.phone.contains(query)
        }
        if (filteredPeople.isEmpty()) {
            Text(v15Text("কোনো $personLabel পাওয়া যায়নি।", "No $personLabel found."))
        } else {
            filteredPeople.forEach { person ->
                val personTone = personAccent(person.id)
                val balanceTone = balanceAccent(person.balance)
                val nextDue = dueItems.filter { it.personId == person.id }.minByOrNull { it.dueAt }
                Card(
                    onClick = { onSelect(person) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = personTone.copy(alpha = 0.09f)),
                    border = BorderStroke(1.dp, personTone.copy(alpha = 0.22f))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(person.name, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium, color = personTone)
                            Text(
                                when {
                                    person.balance > 0 -> v15Text("পাবো", "Receivable")
                                    person.balance < 0 -> v15Text("দেবো", "Payable")
                                    else -> v15Text("সমান", "Settled")
                                },
                                fontWeight = FontWeight.Bold,
                                color = balanceTone
                            )
                        }
                        if (person.phone.isNotBlank()) Text(person.phone, style = MaterialTheme.typography.bodySmall)
                        Text(
                            when {
                                person.balance > 0 -> "${V14DisplayState.currencySymbol} ${money(person.balance)}"
                                person.balance < 0 -> "${V14DisplayState.currencySymbol} ${money(-person.balance)}"
                                else -> "${V14DisplayState.currencySymbol} 0"
                            },
                            fontWeight = FontWeight.Bold,
                            color = balanceTone
                        )
                        nextDue?.let {
                            Text(v15Text("পরবর্তী তারিখ: ${v13Date(it.dueAt)}", "Next due: ${v13Date(it.dueAt)}"), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }

    if (showAdd) {
        var name by remember { mutableStateOf("") }
        var phone by remember { mutableStateOf("") }
        var error by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text(v15Text("নতুন $personLabel", "New $personLabel")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(name, { name = it; error = null }, label = { Text(v15Text("নাম", "Name")) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(phone, { phone = it }, label = { Text(v15Text("ফোন (ঐচ্ছিক)", "Phone (optional)")) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (name.isBlank()) error = v15Text("নাম লিখুন", "Enter a name")
                    else {
                        viewModel.addBakiPerson(name, phone)
                        showAdd = false
                    }
                }) { Text(v15Text("যোগ করুন", "Add")) }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text(v15Text("বাতিল", "Cancel")) } }
        )
    }
}

'''
t = t[:start] + new_people + t[end:]

# Remove the redundant on-screen back button in the ledger; phone Back handles it.
old_back = '''        TextButton(onClick = onBack) {
            Text(if (workspace == "SHOP") "← কাস্টমার/সাপ্লায়ার তালিকায় ফিরুন" else "← ব্যক্তি তালিকায় ফিরুন")
        }

'''
if old_back in t:
    t = t.replace(old_back, '', 1)

# Replace tab label helper for Bangla/English and product tab.
start = t.index('private fun tabLabel(')
end = t.index('private fun tabSymbol(', start)
new_tab_label = '''private fun tabLabel(tab: Tab, workspace: String): String = when (tab) {
    Tab.DASHBOARD -> v15Text("হোম", "Home")
    Tab.ADD -> if (workspace == "SHOP") v15Text("ক্যাশ", "Cash") else v15Text("নতুন", "Add")
    Tab.BAKI -> if (workspace == "SHOP") v15Text("খাতা", "Ledger") else v15Text("বাকি", "Due")
    Tab.PRODUCTS -> v15Text("পণ্য", "Products")
    Tab.HISTORY -> if (workspace == "SHOP") v15Text("লেনদেন", "History") else v15Text("হিসাব", "History")
    Tab.MORE -> v15Text("আরও", "More")
}

'''
t = t[:start] + new_tab_label + t[end:]

# Product symbol/accent cases.
t = must_replace(t, '    Tab.BAKI -> "৳"\n    Tab.HISTORY -> "≡"', '    Tab.BAKI -> "৳"\n    Tab.PRODUCTS -> "▦"\n    Tab.HISTORY -> "≡"', 'product tab symbol')
t = must_replace(t, '    Tab.BAKI -> ReceivableAccent\n    Tab.HISTORY -> Color(0xFF6C4CCF)', '    Tab.BAKI -> ReceivableAccent\n    Tab.PRODUCTS -> ShopAccent\n    Tab.HISTORY -> Color(0xFF6C4CCF)', 'product tab accent')
write(p, t)

# --- Settings: two languages only + product shortcut + hardware back ---
p = "app/src/main/java/com/familykhata/app/ui/V14Settings.kt"
t = read(p)
if 'import androidx.activity.compose.BackHandler' not in t:
    t = must_replace(t, 'import android.widget.Toast\n', 'import android.widget.Toast\nimport androidx.activity.compose.BackHandler\n', 'settings BackHandler import')

t = must_replace(
    t,
    '    onOpenLedger: () -> Unit,\n    onOpenMore: () -> Unit\n)',
    '    onOpenLedger: () -> Unit,\n    onOpenProducts: () -> Unit,\n    onOpenMore: () -> Unit\n)',
    'settings onOpenProducts parameter'
)

# Hardware back closes settings.
anchor = '    val context = LocalContext.current\n    val prefs = remember { context.getSharedPreferences(V14_PREFS, Context.MODE_PRIVATE) }'
t = must_replace(t, anchor, anchor + '\n    BackHandler { onClose() }', 'settings BackHandler')
t = t.replace('"বাংলা সক্রিয় • English/Hindi/Arabic প্রস্তুত করা হবে"', '"বাংলা / English"')

t = must_replace(
    t,
    '        SettingsActionCard("👥", "কাস্টমার / ব্যক্তি খাতা", "নাম বা ফোন দিয়ে খুঁজুন, বাকি ও লেনদেন দেখুন") { onOpenLedger() }\n        SettingsActionCard("↥", "ডাটা ব্যাকআপ ও রিপোর্ট",',
    '        SettingsActionCard("👥", "কাস্টমার / ব্যক্তি খাতা", "নাম বা ফোন দিয়ে খুঁজুন, বাকি ও লেনদেন দেখুন") { onOpenLedger() }\n        SettingsActionCard("📦", "পণ্য / স্টক / Expiry", "ব্যাচ, কেনার তারিখ, মেয়াদ ও low-stock দেখুন") { onOpenProducts() }\n        SettingsActionCard("↥", "ডাটা ব্যাকআপ ও রিপোর্ট",',
    'inventory settings shortcut'
)

t = must_replace(t, '    if (showLanguage) LanguageDialog { showLanguage = false }', '    if (showLanguage) LanguageDialog(context) { showLanguage = false }', 'language dialog call')

start = t.index('@Composable\nprivate fun LanguageDialog(')
end = t.index('private data class CurrencyChoice', start)
new_language_dialog = '''@Composable
private fun LanguageDialog(context: Context, onDismiss: () -> Unit) {
    val current = V15LanguageState.languageCode ?: "bn"
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Select app language") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (current == "bn") {
                    Button(onClick = { V15LanguageState.setLanguage(context, "bn"); onDismiss() }, modifier = Modifier.fillMaxWidth()) { Text("বাংলা ✓") }
                    OutlinedButton(onClick = { V15LanguageState.setLanguage(context, "en"); onDismiss() }, modifier = Modifier.fillMaxWidth()) { Text("English") }
                } else {
                    OutlinedButton(onClick = { V15LanguageState.setLanguage(context, "bn"); onDismiss() }, modifier = Modifier.fillMaxWidth()) { Text("বাংলা") }
                    Button(onClick = { V15LanguageState.setLanguage(context, "en"); onDismiss() }, modifier = Modifier.fillMaxWidth()) { Text("English ✓") }
                }
                Text("Bangla and English are the supported languages in v1.5.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

'''
t = t[:start] + new_language_dialog + t[end:]
t = t.replace('হিসাবী খাতা v1.4 • Offline-first • লোকাল ডেটা', 'হিসাবী খাতা v1.5 • Offline-first • লোকাল ডেটা')
t = t.replace('Text("v1.4", color = MaterialTheme.colorScheme.primary', 'Text("v1.5", color = MaterialTheme.colorScheme.primary')
write(p, t)

# --- Finance backup now includes inventory database ---
p = "app/src/main/java/com/familykhata/app/FamilyKhataViewModel.kt"
t = read(p)
if 'import com.familykhata.app.data.InventoryBackupBridge' not in t:
    t = must_replace(
        t,
        'import com.familykhata.app.data.DueReceivableItem\nimport com.familykhata.app.data.TransactionEntity\n',
        'import com.familykhata.app.data.DueReceivableItem\nimport com.familykhata.app.data.InventoryBackupBridge\nimport com.familykhata.app.data.ProductEntity\nimport com.familykhata.app.data.StockBatchEntity\nimport com.familykhata.app.data.TransactionEntity\n',
        'inventory backup imports'
    )

t = must_replace(
    t,
    '                val entries = dao.getAllBakiEntries()\n\n                JSONObject().apply {',
    '                val entries = dao.getAllBakiEntries()\n                val inventory = InventoryBackupBridge.export(getApplication())\n\n                JSONObject().apply {',
    'inventory export load'
)
t = t.replace('                    put("version", 2)', '                    put("version", 3)', 1)

create_start = t.index('    fun createBackup(')
restore_start = t.index('    fun restoreBackup(', create_start)
create_block = t[create_start:restore_start]
needle = '                }.toString()'
if needle not in create_block:
    raise SystemExit('createBackup JSON end anchor not found')
inventory_json = '''                    put("inventoryProducts", JSONArray().apply {
                        inventory.products.forEach { product ->
                            put(JSONObject().apply {
                                put("id", product.id)
                                put("name", product.name)
                                put("category", product.category)
                                put("sku", product.sku)
                                put("sellingPrice", product.sellingPrice)
                                put("lowStockLevel", product.lowStockLevel)
                                put("note", product.note)
                                put("workspace", product.workspace)
                                put("createdAt", product.createdAt)
                            })
                        }
                    })
                    put("inventoryBatches", JSONArray().apply {
                        inventory.batches.forEach { batch ->
                            put(JSONObject().apply {
                                put("id", batch.id)
                                put("productId", batch.productId)
                                put("quantity", batch.quantity)
                                put("purchasePrice", batch.purchasePrice)
                                put("purchaseDate", batch.purchaseDate)
                                if (batch.expiryDate != null) put("expiryDate", batch.expiryDate)
                                put("createdAt", batch.createdAt)
                            })
                        }
                    })
'''
create_block = create_block.replace(needle, inventory_json + needle, 1)
t = t[:create_start] + create_block + t[restore_start:]

t = t.replace('require(backupVersion in 1..2)', 'require(backupVersion in 1..3)', 1)
t = must_replace(
    t,
    '                val entries = mutableListOf<BakiEntryEntity>()\n                val actions = setOf("GAVE", "RECEIVED_BACK", "TOOK", "PAID_BACK")',
    '                val entries = mutableListOf<BakiEntryEntity>()\n                val inventoryProducts = mutableListOf<ProductEntity>()\n                val inventoryBatches = mutableListOf<StockBatchEntity>()\n                val actions = setOf("GAVE", "RECEIVED_BACK", "TOOK", "PAID_BACK")',
    'inventory restore lists'
)

restore_start = t.index('    fun restoreBackup(')
restore_block = t[restore_start:]
anchor = '\n                database.withTransaction {'
idx = restore_block.index(anchor)
parse_inventory = '''
                if (backupVersion >= 3) {
                    val productArray = root.optJSONArray("inventoryProducts") ?: JSONArray()
                    for (index in 0 until productArray.length()) {
                        val item = productArray.getJSONObject(index)
                        val name = item.getString("name").trim()
                        val workspace = item.optString("workspace", "SHOP")
                        require(name.isNotBlank()) { "পণ্যের নাম খালি হতে পারে না" }
                        require(workspace in allowedWorkspaces) { "পণ্যের workspace সঠিক নয়" }
                        inventoryProducts += ProductEntity(
                            id = item.getLong("id"),
                            name = name,
                            category = item.optString("category", ""),
                            sku = item.optString("sku", ""),
                            sellingPrice = item.optDouble("sellingPrice", 0.0).coerceAtLeast(0.0),
                            lowStockLevel = item.optInt("lowStockLevel", 0).coerceAtLeast(0),
                            note = item.optString("note", ""),
                            workspace = workspace,
                            createdAt = item.optLong("createdAt", System.currentTimeMillis())
                        )
                    }
                    val productIds = inventoryProducts.map { it.id }.toSet()
                    val batchArray = root.optJSONArray("inventoryBatches") ?: JSONArray()
                    for (index in 0 until batchArray.length()) {
                        val item = batchArray.getJSONObject(index)
                        val productId = item.getLong("productId")
                        require(productId in productIds) { "স্টক ব্যাচের পণ্য পাওয়া যায়নি" }
                        inventoryBatches += StockBatchEntity(
                            id = item.getLong("id"),
                            productId = productId,
                            quantity = item.optInt("quantity", 0).coerceAtLeast(0),
                            purchasePrice = item.optDouble("purchasePrice", 0.0).coerceAtLeast(0.0),
                            purchaseDate = item.optLong("purchaseDate", System.currentTimeMillis()),
                            expiryDate = item.optLong("expiryDate", 0L).takeIf { it > 0L },
                            createdAt = item.optLong("createdAt", System.currentTimeMillis())
                        )
                    }
                }
'''
restore_block = restore_block[:idx] + parse_inventory + restore_block[idx:]
old_count = '''                transactions.size + people.size + entries.size
'''
new_count = '''                if (backupVersion >= 3) {
                    InventoryBackupBridge.restore(getApplication(), inventoryProducts, inventoryBatches)
                }

                transactions.size + people.size + entries.size + inventoryProducts.size + inventoryBatches.size
'''
if old_count not in restore_block:
    raise SystemExit('restore count anchor not found')
restore_block = restore_block.replace(old_count, new_count, 1)
t = t[:restore_start] + restore_block
write(p, t)

print('v1.5 source patch checks passed')
PY

# Copy new v1.5 source files only after all text patch anchors succeeded.
cp -R v15_payload/app/src/main/java/com/familykhata/app/data/InventoryModels.kt app/src/main/java/com/familykhata/app/data/
cp -R v15_payload/app/src/main/java/com/familykhata/app/data/InventoryDao.kt app/src/main/java/com/familykhata/app/data/
cp -R v15_payload/app/src/main/java/com/familykhata/app/data/InventoryDatabase.kt app/src/main/java/com/familykhata/app/data/
cp -R v15_payload/app/src/main/java/com/familykhata/app/InventoryViewModel.kt app/src/main/java/com/familykhata/app/
cp -R v15_payload/app/src/main/java/com/familykhata/app/InventoryReminderWorker.kt app/src/main/java/com/familykhata/app/
cp -R v15_payload/app/src/main/java/com/familykhata/app/ui/V15Language.kt app/src/main/java/com/familykhata/app/ui/
cp -R v15_payload/app/src/main/java/com/familykhata/app/ui/V15Inventory.kt app/src/main/java/com/familykhata/app/ui/

echo "===== V1.5 PATCH APPLIED ====="
grep 'versionCode' app/build.gradle.kts
grep 'versionName' app/build.gradle.kts
git status --short
